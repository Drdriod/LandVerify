"""LandVerify — Configuration"""
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # App
    app_name: str = "LandVerify API"
    app_version: str = "1.0.0"
    debug: bool = True
    secret_key: str = "landverify-dev-secret-key-change-in-production-64chars"

    # AI — set ANTHROPIC_API_KEY in .env
    anthropic_api_key: str = "placeholder"
    claude_model: str = "claude-opus-4-6"

    # Database
    database_url: str = "postgresql+asyncpg://landverify:landverify@localhost:5432/landverify"

    # Redis (optional — alerts/caching)
    redis_url: str = "redis://localhost:6379"

    # Email (Mailgun) — stub mode when empty
    mailgun_api_key: str = ""
    mailgun_domain: str = "mg.landverify.ng"
    from_email: str = "noreply@landverify.ng"

    # SMS (Termii) — stub mode when empty
    termii_api_key: str = ""
    termii_sender_id: str = "LandVerify"

    # Payments (Paystack) — stub mode when empty
    paystack_secret_key: str = ""
    paystack_public_key: str = ""

    # Trust Score weights (must sum to 1.0)
    weight_document_authenticity: float = 0.30
    weight_registry_match: float = 0.25
    weight_ownership_chain: float = 0.20
    weight_encumbrance_check: float = 0.15
    weight_geospatial_match: float = 0.10

    class Config:
        env_file = ".env"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    return Settings()
