"""
LandVerify — Data Models
All Pydantic models for requests, responses, and internal data.
"""
from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum
from datetime import datetime


# ─────────────────────────────────────────────
# ENUMS
# ─────────────────────────────────────────────

class DocumentType(str, Enum):
    C_OF_O = "certificate_of_occupancy"
    DEED_OF_ASSIGNMENT = "deed_of_assignment"
    SURVEY_PLAN = "survey_plan"
    GOVERNORS_CONSENT = "governors_consent"
    RIGHT_OF_OCCUPANCY = "right_of_occupancy"
    EXCISION = "excision"
    DEED_OF_GIFT = "deed_of_gift"
    PROBATE = "probate"


class NigerianState(str, Enum):
    LAGOS = "lagos"
    ABUJA = "abuja_fct"
    RIVERS = "rivers"
    OGUN = "ogun"
    KANO = "kano"
    ENUGU = "enugu"
    DELTA = "delta"
    OYO = "oyo"
    KADUNA = "kaduna"
    ANAMBRA = "anambra"
    OTHER = "other"


class TrustLevel(str, Enum):
    SAFE = "safe"           # Score 75–100
    CAUTION = "caution"     # Score 50–74
    DANGER = "danger"       # Score 0–49


class UserRole(str, Enum):
    BUYER = "buyer"
    LAWYER = "lawyer"
    BANK = "bank"
    DEVELOPER = "developer"
    SELLER = "seller"


class FraudSeverity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class CheckStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    WARNING = "warning"
    PENDING = "pending"


# ─────────────────────────────────────────────
# DOCUMENT MODELS
# ─────────────────────────────────────────────

class DocumentMetadata(BaseModel):
    """Metadata extracted from a land document."""
    file_number: Optional[str] = None
    document_type: Optional[DocumentType] = None
    state: Optional[NigerianState] = None
    issue_date: Optional[str] = None
    owner_name: Optional[str] = None
    property_address: Optional[str] = None
    plot_number: Optional[str] = None
    survey_plan_number: Optional[str] = None
    stamp_duty_reference: Optional[str] = None
    governor_name: Optional[str] = None
    coordinates: Optional[str] = None
    land_size: Optional[str] = None
    raw_text: Optional[str] = None


class VerificationRequest(BaseModel):
    """Request body for document verification."""
    document_type: DocumentType
    state: NigerianState
    property_address: str = Field(..., min_length=5)
    owner_name: str = Field(..., min_length=2)
    file_number: Optional[str] = None
    user_role: UserRole
    additional_notes: Optional[str] = None
    # extracted_text will be populated from OCR
    extracted_text: Optional[str] = None


# ─────────────────────────────────────────────
# VERIFICATION CHECK MODELS
# ─────────────────────────────────────────────

class VerificationCheck(BaseModel):
    """A single verification check result."""
    check_id: str
    label: str
    status: CheckStatus
    detail: str
    weight: float  # How much this check affects the Trust Score
    evidence: Optional[str] = None


class FraudFlag(BaseModel):
    """A detected fraud indicator."""
    flag_id: str
    severity: FraudSeverity
    title: str
    description: str
    recommendation: str
    confidence: float = Field(..., ge=0.0, le=1.0)


# ─────────────────────────────────────────────
# OWNERSHIP CHAIN MODELS
# ─────────────────────────────────────────────

class OwnershipRecord(BaseModel):
    """A single record in the ownership history chain."""
    year: str
    owner_name: str
    transaction_type: str  # e.g. "Original Allocation", "Purchase", "Inheritance"
    consideration: Optional[str] = None  # Price paid
    instrument: Optional[str] = None  # e.g. "Deed of Assignment No. 45"
    registered: bool = True
    flagged: bool = False
    flag_reason: Optional[str] = None


class OwnershipChain(BaseModel):
    """Complete ownership history of a property."""
    property_id: str
    total_owners: int
    chain_integrity: float  # 0.0 to 1.0
    has_gaps: bool
    has_disputes: bool
    records: List[OwnershipRecord]
    analysis_summary: str


# ─────────────────────────────────────────────
# TRUST SCORE MODELS
# ─────────────────────────────────────────────

class TrustScoreBreakdown(BaseModel):
    """Breakdown of how the Trust Score was calculated."""
    document_authenticity_score: float
    registry_match_score: float
    ownership_chain_score: float
    encumbrance_score: float
    geospatial_score: float
    fraud_penalty: float
    final_score: float
    trust_level: TrustLevel


# ─────────────────────────────────────────────
# FULL VERIFICATION RESULT
# ─────────────────────────────────────────────

class VerificationResult(BaseModel):
    """Complete verification result returned to the client."""
    verification_id: str
    timestamp: datetime
    property_address: str
    document_type: DocumentType
    state: NigerianState

    # Trust Score
    trust_score: float = Field(..., ge=0.0, le=100.0)
    trust_level: TrustLevel
    trust_score_breakdown: TrustScoreBreakdown

    # Checks
    checks: List[VerificationCheck]
    checks_passed: int
    checks_failed: int
    checks_warned: int

    # Fraud
    fraud_flags: List[FraudFlag]
    fraud_risk_summary: str

    # Ownership
    ownership_chain: OwnershipChain

    # AI Analysis
    ai_summary: str
    ai_recommendation: str

    # Meta
    verified_by: str = "LandVerify AI v1.0 — Powered by Claude"


# ─────────────────────────────────────────────
# ALERT MODELS
# ─────────────────────────────────────────────

class AlertType(str, Enum):
    DUPLICATE_TITLE = "duplicate_title"
    UNREGISTERED_TRANSFER = "unregistered_transfer"
    SUSPICIOUS_AGENT = "suspicious_agent"
    REGISTRY_MISMATCH = "registry_mismatch"
    ENCUMBRANCE_ADDED = "encumbrance_added"
    OWNERSHIP_DISPUTE = "ownership_dispute"


class FraudAlert(BaseModel):
    """A fraud alert for a monitored property."""
    alert_id: str
    property_id: str
    property_address: str
    alert_type: AlertType
    severity: FraudSeverity
    title: str
    description: str
    recommended_action: str
    timestamp: datetime
    resolved: bool = False


class AlertRegistration(BaseModel):
    """Request to register a property for fraud monitoring."""
    property_name: str
    property_address: str
    file_number: str
    owner_name: str
    state: NigerianState
    document_type: DocumentType
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None
