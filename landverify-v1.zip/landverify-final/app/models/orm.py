"""
LandVerify — ORM Models
SQLAlchemy models that map directly to the PostgreSQL schema.
"""
import uuid
from datetime import datetime
from typing import Optional, List

from sqlalchemy import (
    Column, String, Boolean, Integer, Float, Text, DateTime,
    ForeignKey, SmallInteger, BigInteger, ARRAY, JSON, Numeric,
    Enum as SAEnum, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import relationship, mapped_column, Mapped
from sqlalchemy.sql import func

from app.database import Base


# ── Helpers ──────────────────────────────────────────────
def uuid_pk():
    return Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

def now_col():
    return Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

def fk(table_col, **kw):
    return Column(UUID(as_uuid=True), ForeignKey(table_col), **kw)


# ═══════════════════════════════════════════════════════════
# USERS
# ═══════════════════════════════════════════════════════════
class User(Base):
    __tablename__ = "users"

    id              = uuid_pk()
    email           = Column(String(255), unique=True, nullable=False, index=True)
    phone           = Column(String(20), index=True)
    full_name       = Column(String(255), nullable=False)
    password_hash   = Column(Text, nullable=False)
    role            = Column(String(20), nullable=False, default="buyer")
    plan            = Column(String(20), nullable=False, default="free")

    # Profile
    nin             = Column(String(11))
    bvn             = Column(String(11))
    cac_number      = Column(String(20))
    profession      = Column(String(100))
    organization_id = fk("organizations.id", nullable=True)

    # Verification status
    email_verified      = Column(Boolean, nullable=False, default=False)
    phone_verified      = Column(Boolean, nullable=False, default=False)
    identity_verified   = Column(Boolean, nullable=False, default=False)
    kyc_completed_at    = Column(DateTime(timezone=True))

    # Usage
    verifications_used  = Column(Integer, nullable=False, default=0)
    verifications_limit = Column(Integer, nullable=False, default=3)
    last_active_at      = Column(DateTime(timezone=True))

    # Billing
    stripe_customer_id  = Column(String(100))

    # Timestamps
    created_at  = now_col()
    updated_at  = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    deleted_at  = Column(DateTime(timezone=True))

    # Relationships
    verifications       = relationship("Verification", back_populates="user", lazy="select")
    alert_subscriptions = relationship("AlertSubscription", back_populates="user", lazy="select")
    api_keys            = relationship("ApiKey", foreign_keys="ApiKey.created_by", lazy="select")

    def is_active(self) -> bool:
        return self.deleted_at is None

    def can_verify(self) -> bool:
        """Check if user has verification quota remaining."""
        if self.plan != "free":
            return True
        return self.verifications_used < self.verifications_limit

    def __repr__(self):
        return f"<User {self.email} [{self.plan}]>"


# ═══════════════════════════════════════════════════════════
# ORGANIZATIONS
# ═══════════════════════════════════════════════════════════
class Organization(Base):
    __tablename__ = "organizations"

    id          = uuid_pk()
    name        = Column(String(255), nullable=False)
    cac_number  = Column(String(20), unique=True)
    email       = Column(String(255), nullable=False)
    phone       = Column(String(20))
    address     = Column(Text)
    state       = Column(String(50))
    type        = Column(String(50))
    plan        = Column(String(20), nullable=False, default="professional")

    api_calls_used  = Column(Integer, nullable=False, default=0)
    api_calls_limit = Column(Integer, nullable=False, default=1000)

    verified    = Column(Boolean, nullable=False, default=False)
    verified_at = Column(DateTime(timezone=True))

    created_at  = now_col()
    updated_at  = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    # Relationships
    members     = relationship("User", back_populates="organization", lazy="select")
    api_keys    = relationship("ApiKey", back_populates="organization", lazy="select")

    # Back-ref
    User.organization = relationship("Organization", back_populates="members", foreign_keys=[User.organization_id])


# ═══════════════════════════════════════════════════════════
# PROPERTIES
# ═══════════════════════════════════════════════════════════
class Property(Base):
    __tablename__ = "properties"

    id                  = uuid_pk()
    address             = Column(Text, nullable=False)
    state               = Column(String(50), nullable=False, index=True)
    lga                 = Column(String(100))
    plot_number         = Column(String(50))
    file_number         = Column(String(50), index=True)
    survey_plan_number  = Column(String(50))

    # Geospatial (stored as strings when PostGIS unavailable)
    latitude            = Column(Float)
    longitude           = Column(Float)
    land_size_sqm       = Column(Numeric(12, 4))

    # Title
    document_type       = Column(String(50))
    title_holder        = Column(String(255))

    # Latest Trust Score (denormalized)
    current_trust_score = Column(Numeric(5, 2))
    current_trust_level = Column(String(10))
    last_verified_at    = Column(DateTime(timezone=True))

    # Flags
    is_monitored            = Column(Boolean, nullable=False, default=False)
    has_active_alert        = Column(Boolean, nullable=False, default=False)
    is_disputed             = Column(Boolean, nullable=False, default=False)
    is_government_acquired  = Column(Boolean, nullable=False, default=False)

    created_by  = fk("users.id", nullable=True)
    created_at  = now_col()
    updated_at  = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    deleted_at  = Column(DateTime(timezone=True))

    # Relationships
    documents       = relationship("Document", back_populates="property", lazy="select")
    verifications   = relationship("Verification", back_populates="property", lazy="select")
    trust_scores    = relationship("TrustScore", back_populates="property", lazy="select",
                                   order_by="TrustScore.recorded_at.desc()")
    fraud_alerts    = relationship("FraudAlert", back_populates="property", lazy="select")
    ownership_records = relationship("OwnershipRecord", back_populates="property",
                                     order_by="OwnershipRecord.sequence_order", lazy="select")
    subscriptions   = relationship("AlertSubscription", back_populates="property", lazy="select")

    def __repr__(self):
        return f"<Property {self.address[:40]} [{self.state}]>"


# ═══════════════════════════════════════════════════════════
# DOCUMENTS
# ═══════════════════════════════════════════════════════════
class Document(Base):
    __tablename__ = "documents"

    id              = uuid_pk()
    property_id     = fk("properties.id", nullable=True)
    uploaded_by     = fk("users.id", nullable=False)

    filename        = Column(String(255), nullable=False)
    file_size_bytes = Column(Integer, nullable=False)
    mime_type       = Column(String(50), nullable=False)
    storage_key     = Column(Text, nullable=False)
    storage_bucket  = Column(String(100))

    # OCR results
    document_type           = Column(String(50))
    declared_type           = Column(String(50))
    extracted_text          = Column(Text)
    extraction_confidence   = Column(Numeric(4, 3))

    # Parsed fields
    parsed_file_number      = Column(String(50), index=True)
    parsed_owner_name       = Column(String(255))
    parsed_issue_date       = Column(DateTime(timezone=True))
    parsed_stamp_duty_ref   = Column(String(50))
    parsed_governor_name    = Column(String(100))
    parsed_survey_plan_no   = Column(String(50))
    parsed_land_size        = Column(String(50))
    parsed_coordinates      = Column(String(100))

    format_authenticity_score = Column(Numeric(4, 3))

    is_potentially_forged   = Column(Boolean, nullable=False, default=False)
    is_duplicate            = Column(Boolean, nullable=False, default=False)
    duplicate_document_id   = fk("documents.id", nullable=True)

    created_at  = now_col()

    # Relationships
    property    = relationship("Property", back_populates="documents")
    uploader    = relationship("User", foreign_keys=[uploaded_by])


# ═══════════════════════════════════════════════════════════
# VERIFICATIONS
# ═══════════════════════════════════════════════════════════
class Verification(Base):
    __tablename__ = "verifications"

    id              = uuid_pk()
    user_id         = fk("users.id", nullable=False)
    property_id     = fk("properties.id", nullable=True)
    document_id     = fk("documents.id", nullable=True)
    organization_id = fk("organizations.id", nullable=True)

    status          = Column(String(20), nullable=False, default="pending")
    started_at      = now_col()
    completed_at    = Column(DateTime(timezone=True))
    processing_ms   = Column(Integer)

    # Input
    declared_address        = Column(Text, nullable=False)
    declared_owner          = Column(String(255), nullable=False)
    declared_state          = Column(String(50), nullable=False)
    declared_doc_type       = Column(String(50), nullable=False)
    declared_file_number    = Column(String(50))
    user_role               = Column(String(20), nullable=False)
    additional_notes        = Column(Text)

    # Results
    trust_score         = Column(Numeric(5, 2))
    trust_level         = Column(String(10))
    checks_passed       = Column(SmallInteger)
    checks_failed       = Column(SmallInteger)
    checks_warned       = Column(SmallInteger)

    # Score breakdown
    score_document_authenticity = Column(Numeric(5, 2))
    score_registry_match        = Column(Numeric(5, 2))
    score_ownership_chain       = Column(Numeric(5, 2))
    score_encumbrance           = Column(Numeric(5, 2))
    score_geospatial            = Column(Numeric(5, 2))
    fraud_penalty               = Column(Numeric(5, 2))

    # AI output
    ai_summary          = Column(Text)
    ai_recommendation   = Column(Text)
    fraud_risk_summary  = Column(Text)
    fraud_risk_level    = Column(String(20))

    # Ownership summary
    ownership_total_owners      = Column(SmallInteger)
    ownership_chain_integrity   = Column(Numeric(4, 3))
    ownership_has_gaps          = Column(Boolean)
    ownership_has_disputes      = Column(Boolean)

    is_demo         = Column(Boolean, nullable=False, default=False)
    api_version     = Column(String(10), default="v1")
    ai_model_used   = Column(String(50))

    created_at  = now_col()

    # Relationships
    user            = relationship("User", back_populates="verifications")
    property        = relationship("Property", back_populates="verifications")
    checks          = relationship("VerificationCheck", back_populates="verification",
                                   cascade="all, delete-orphan")
    fraud_flags     = relationship("FraudFlag", back_populates="verification",
                                   cascade="all, delete-orphan")
    ownership_records = relationship("OwnershipRecord", back_populates="verification")
    trust_score_record = relationship("TrustScore", back_populates="verification", uselist=False)


# ═══════════════════════════════════════════════════════════
# VERIFICATION CHECKS
# ═══════════════════════════════════════════════════════════
class VerificationCheck(Base):
    __tablename__ = "verification_checks"

    id              = uuid_pk()
    verification_id = fk("verifications.id", nullable=False)

    check_id    = Column(String(50), nullable=False)
    label       = Column(String(100), nullable=False)
    status      = Column(String(20), nullable=False)
    detail      = Column(Text, nullable=False)
    weight      = Column(Numeric(4, 3), nullable=False)
    evidence    = Column(Text)

    created_at  = now_col()

    verification = relationship("Verification", back_populates="checks")


# ═══════════════════════════════════════════════════════════
# TRUST SCORES
# ═══════════════════════════════════════════════════════════
class TrustScore(Base):
    __tablename__ = "trust_scores"

    id              = uuid_pk()
    property_id     = fk("properties.id", nullable=False)
    verification_id = fk("verifications.id", nullable=True)

    score           = Column(Numeric(5, 2), nullable=False)
    trust_level     = Column(String(10), nullable=False)

    doc_authenticity    = Column(Numeric(5, 2))
    registry_match      = Column(Numeric(5, 2))
    ownership_chain     = Column(Numeric(5, 2))
    encumbrance         = Column(Numeric(5, 2))
    geospatial          = Column(Numeric(5, 2))
    fraud_penalty       = Column(Numeric(5, 2))

    score_delta     = Column(Numeric(5, 2))
    change_reason   = Column(Text)

    recorded_at     = now_col()

    property        = relationship("Property", back_populates="trust_scores")
    verification    = relationship("Verification", back_populates="trust_score_record")


# ═══════════════════════════════════════════════════════════
# FRAUD FLAGS
# ═══════════════════════════════════════════════════════════
class FraudFlag(Base):
    __tablename__ = "fraud_flags"

    id              = uuid_pk()
    verification_id = fk("verifications.id", nullable=False)
    property_id     = fk("properties.id", nullable=True)

    flag_id         = Column(String(50), nullable=False, index=True)
    source          = Column(String(20), nullable=False)
    severity        = Column(String(20), nullable=False, index=True)
    title           = Column(String(255), nullable=False)
    description     = Column(Text, nullable=False)
    recommendation  = Column(Text, nullable=False)
    confidence      = Column(Numeric(4, 3), nullable=False)

    is_resolved     = Column(Boolean, nullable=False, default=False)
    resolved_at     = Column(DateTime(timezone=True))
    resolved_by     = fk("users.id", nullable=True)
    resolution_notes = Column(Text)

    created_at      = now_col()

    verification    = relationship("Verification", back_populates="fraud_flags")
    property        = relationship("Property")


# ═══════════════════════════════════════════════════════════
# OWNERSHIP RECORDS
# ═══════════════════════════════════════════════════════════
class OwnershipRecord(Base):
    __tablename__ = "ownership_records"

    id              = uuid_pk()
    property_id     = fk("properties.id", nullable=False)
    verification_id = fk("verifications.id", nullable=True)

    sequence_order  = Column(SmallInteger, nullable=False)
    year            = Column(String(10), nullable=False)
    event_date      = Column(DateTime(timezone=True))
    owner_name      = Column(String(255), nullable=False)
    transaction_type = Column(String(50), nullable=False)
    consideration   = Column(String(100))
    instrument      = Column(Text)

    is_registered   = Column(Boolean, nullable=False, default=True)
    registry_ref    = Column(String(100))
    is_flagged      = Column(Boolean, nullable=False, default=False)
    flag_reason     = Column(Text)
    is_gap          = Column(Boolean, nullable=False, default=False)
    ai_confidence   = Column(Numeric(4, 3))

    created_at      = now_col()

    property        = relationship("Property", back_populates="ownership_records")
    verification    = relationship("Verification", back_populates="ownership_records")

    __table_args__ = (
        UniqueConstraint("property_id", "sequence_order", name="uq_ownership_sequence"),
    )


# ═══════════════════════════════════════════════════════════
# FRAUD ALERTS
# ═══════════════════════════════════════════════════════════
class FraudAlert(Base):
    __tablename__ = "fraud_alerts"

    id              = uuid_pk()
    property_id     = fk("properties.id", nullable=False)

    alert_type      = Column(String(50), nullable=False)
    severity        = Column(String(20), nullable=False)
    title           = Column(String(255), nullable=False)
    description     = Column(Text, nullable=False)
    recommended_action = Column(Text, nullable=False)

    triggered_by    = Column(String(50))
    source_verification_id = fk("verifications.id", nullable=True)

    is_notified     = Column(Boolean, nullable=False, default=False)
    notified_at     = Column(DateTime(timezone=True))

    is_resolved     = Column(Boolean, nullable=False, default=False, index=True)
    resolved_at     = Column(DateTime(timezone=True))
    resolved_by     = fk("users.id", nullable=True)
    resolution_notes = Column(Text)

    created_at      = now_col()

    property        = relationship("Property", back_populates="fraud_alerts")


# ═══════════════════════════════════════════════════════════
# ALERT SUBSCRIPTIONS
# ═══════════════════════════════════════════════════════════
class AlertSubscription(Base):
    __tablename__ = "alert_subscriptions"

    id          = uuid_pk()
    user_id     = fk("users.id", nullable=False)
    property_id = fk("properties.id", nullable=False)

    notify_email        = Column(Boolean, nullable=False, default=True)
    notify_sms          = Column(Boolean, nullable=False, default=False)
    notify_push         = Column(Boolean, nullable=False, default=True)
    alert_on_any        = Column(Boolean, nullable=False, default=True)
    alert_severity_min  = Column(String(20), default="low")

    subscribed_at   = now_col()
    cancelled_at    = Column(DateTime(timezone=True))

    user        = relationship("User", back_populates="alert_subscriptions")
    property    = relationship("Property", back_populates="subscriptions")

    __table_args__ = (
        UniqueConstraint("user_id", "property_id", name="uq_subscription"),
    )


# ═══════════════════════════════════════════════════════════
# API KEYS
# ═══════════════════════════════════════════════════════════
class ApiKey(Base):
    __tablename__ = "api_keys"

    id              = uuid_pk()
    organization_id = fk("organizations.id", nullable=False)
    created_by      = fk("users.id", nullable=False)

    name            = Column(String(100), nullable=False)
    key_hash        = Column(Text, nullable=False, unique=True)
    key_prefix      = Column(String(8), nullable=False, index=True)

    can_verify      = Column(Boolean, nullable=False, default=True)
    can_read_alerts = Column(Boolean, nullable=False, default=True)
    can_register_property = Column(Boolean, nullable=False, default=False)
    can_admin       = Column(Boolean, nullable=False, default=False)

    rate_limit_per_min  = Column(Integer, nullable=False, default=30)
    rate_limit_per_day  = Column(Integer, nullable=False, default=1000)

    total_calls     = Column(BigInteger, nullable=False, default=0)
    last_used_at    = Column(DateTime(timezone=True))
    last_used_ip    = Column(INET)

    expires_at      = Column(DateTime(timezone=True))
    revoked_at      = Column(DateTime(timezone=True))
    revoked_by      = fk("users.id", nullable=True)
    revoke_reason   = Column(Text)

    created_at      = now_col()

    organization    = relationship("Organization", back_populates="api_keys")


# ═══════════════════════════════════════════════════════════
# AUDIT LOG
# ═══════════════════════════════════════════════════════════
class AuditLog(Base):
    __tablename__ = "audit_log"

    id              = Column(BigInteger, primary_key=True, autoincrement=True)
    user_id         = fk("users.id", nullable=True)
    organization_id = fk("organizations.id", nullable=True)

    action          = Column(String(100), nullable=False, index=True)
    resource_type   = Column(String(50))
    resource_id     = Column(UUID(as_uuid=True))
    ip_address      = Column(INET)
    user_agent      = Column(Text)

    old_values      = Column(JSONB)
    new_values      = Column(JSONB)
    metadata_       = Column("metadata", JSONB)

    created_at      = now_col()

    __table_args__ = (
        Index("idx_audit_user_date", "user_id", "created_at"),
        Index("idx_audit_resource", "resource_type", "resource_id"),
    )
