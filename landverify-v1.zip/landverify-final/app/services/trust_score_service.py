"""
LandVerify — Trust Score Service
The core algorithm that calculates the LandVerify Trust Score (0–100).

The Trust Score is a weighted composite of:
  - Document Authenticity (30%)
  - Registry Match (25%)
  - Ownership Chain Integrity (20%)
  - Encumbrance Check (15%)
  - Geospatial Verification (10%)
  - Fraud Penalty (deducted from total)
"""
import logging
from typing import Optional

from app.config import get_settings
from app.models.document import TrustScoreBreakdown, TrustLevel

logger = logging.getLogger(__name__)
settings = get_settings()


class TrustScoreService:
    """
    Calculates the LandVerify Trust Score using a weighted algorithm.

    Score bands:
      75–100 → SAFE (Green) — Document appears authentic, proceed with standard diligence
      50–74  → CAUTION (Amber) — Anomalies detected, investigate further before proceeding
      0–49   → DANGER (Red) — High fraud risk, do not proceed, seek legal advice immediately
    """

    # Configurable weights from settings
    @property
    def weights(self) -> dict:
        return {
            "document_authenticity": settings.weight_document_authenticity,  # 0.30
            "registry_match":        settings.weight_registry_match,          # 0.25
            "ownership_chain":       settings.weight_ownership_chain,         # 0.20
            "encumbrance_check":     settings.weight_encumbrance_check,       # 0.15
            "geospatial_match":      settings.weight_geospatial_match,        # 0.10
        }

    def calculate(
        self,
        authenticity_score: float,          # 0.0–1.0 from Claude analysis
        registry_match_score: float,         # 0.0–1.0 from registry lookup
        ownership_chain_integrity: float,    # 0.0–1.0 from ownership service
        encumbrance_score: float,            # 0.0–1.0 (1.0 = no encumbrances)
        geospatial_score: float,             # 0.0–1.0 from coordinates check
        fraud_flags: list,                   # List of FraudFlag objects
    ) -> TrustScoreBreakdown:
        """
        Calculate the composite Trust Score.

        Returns a TrustScoreBreakdown with individual component scores
        and the final weighted score out of 100.
        """
        w = self.weights

        # Weighted component scores (each already 0.0–1.0)
        doc_contribution    = authenticity_score   * w["document_authenticity"]
        registry_contribution = registry_match_score * w["registry_match"]
        ownership_contribution = ownership_chain_integrity * w["ownership_chain"]
        encumbrance_contribution = encumbrance_score * w["encumbrance_check"]
        geo_contribution    = geospatial_score     * w["geospatial_match"]

        # Raw score before fraud penalty (0.0–1.0)
        raw_score = (
            doc_contribution +
            registry_contribution +
            ownership_contribution +
            encumbrance_contribution +
            geo_contribution
        )

        # Fraud penalty — deducted based on severity of flags
        fraud_penalty = self._calculate_fraud_penalty(fraud_flags)

        # Final score, clamped to 0–100
        final_score = max(0.0, min(100.0, (raw_score - fraud_penalty) * 100))

        return TrustScoreBreakdown(
            document_authenticity_score=round(authenticity_score * 100, 1),
            registry_match_score=round(registry_match_score * 100, 1),
            ownership_chain_score=round(ownership_chain_integrity * 100, 1),
            encumbrance_score=round(encumbrance_score * 100, 1),
            geospatial_score=round(geospatial_score * 100, 1),
            fraud_penalty=round(fraud_penalty * 100, 1),
            final_score=round(final_score, 1),
            trust_level=self._score_to_level(final_score),
        )

    def _calculate_fraud_penalty(self, fraud_flags: list) -> float:
        """
        Calculate total penalty from fraud flags.

        Severity → Penalty (as proportion of total score):
          CRITICAL  → 0.40 (40 points off)
          HIGH      → 0.20 (20 points off)
          MEDIUM    → 0.10 (10 points off)
          LOW       → 0.03 (3 points off)

        Penalties are additive up to a maximum of 0.60 (60 points).
        This ensures even a document with many low-level flags
        cannot score 0 without at least one critical flag.
        """
        from app.models.document import FraudSeverity

        severity_penalties = {
            FraudSeverity.CRITICAL: 0.40,
            FraudSeverity.HIGH:     0.20,
            FraudSeverity.MEDIUM:   0.10,
            FraudSeverity.LOW:      0.03,
        }

        total_penalty = 0.0
        for flag in fraud_flags:
            severity = getattr(flag, 'severity', None)
            if severity:
                penalty = severity_penalties.get(severity, 0.0)
                # Confidence-weighted penalty
                confidence = getattr(flag, 'confidence', 1.0)
                total_penalty += penalty * confidence

        # Cap at 0.60 to prevent nonsensical negative scores
        return min(total_penalty, 0.60)

    def _score_to_level(self, score: float) -> TrustLevel:
        """Convert numeric score to trust level enum."""
        if score >= 75:
            return TrustLevel.SAFE
        elif score >= 50:
            return TrustLevel.CAUTION
        else:
            return TrustLevel.DANGER

    def mock_registry_score(self, file_number: Optional[str], state: str) -> float:
        """
        STUB: Simulates a registry lookup score.
        In production, this calls the state land registry API.

        Returns 1.0 if found, 0.5 if partially matched, 0.0 if not found.
        Until state APIs are integrated, uses heuristic scoring.
        """
        if not file_number:
            logger.warning("No file number provided — registry score defaulting to 0.4")
            return 0.4

        # Nigerian file number format validation: XX/XX/YYYY/NNNNNN
        import re
        pattern = r"^[A-Z]{1,3}/[A-Z]{1,3}/\d{4}/\d{3,8}$"
        if re.match(pattern, file_number.strip()):
            logger.info(f"File number {file_number} matches valid format — mock score 0.75")
            return 0.75
        else:
            logger.warning(f"File number {file_number} does not match expected format")
            return 0.35

    def mock_geospatial_score(self, coordinates: Optional[str], state: str) -> float:
        """
        STUB: Simulates a geospatial boundary verification.
        In production, cross-references GPS coordinates against known
        property boundaries using GIS data.
        """
        if not coordinates:
            return 0.5  # Neutral — no coordinates to check

        # Nigerian coordinate bounds check
        # Nigeria: Lat 4.2–13.9N, Lon 2.7–14.7E
        import re
        lat_match = re.search(r"(\d+\.\d+)[NS]?", coordinates)
        if lat_match:
            lat = float(lat_match.group(1))
            if 4.0 <= lat <= 14.0:
                return 0.85  # Within Nigeria bounds
            else:
                return 0.1   # Outside Nigeria — likely fake coordinates
        return 0.5

    def mock_encumbrance_score(self, document_text: Optional[str]) -> float:
        """
        STUB: Checks for mortgages, liens, and encumbrances.
        In production, queries CBN mortgage registry and court records.
        """
        if not document_text:
            return 0.6

        encumbrance_keywords = [
            "mortgage", "charge", "lien", "encumbrance",
            "court order", "injunction", "caveat", "attachment"
        ]

        text_lower = document_text.lower()
        found = [kw for kw in encumbrance_keywords if kw in text_lower]

        if not found:
            return 1.0   # No encumbrances detected
        elif len(found) == 1:
            return 0.65  # One encumbrance — warrants investigation
        else:
            return 0.30  # Multiple encumbrances — high risk


# Singleton instance
trust_score_service = TrustScoreService()
