"""
LandVerify — Email Service
Sends transactional emails via Mailgun.
Stubs log to console when MAILGUN_API_KEY is not set (dev mode).
"""
import logging, httpx
from typing import Optional

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        try:
            from app.config import get_settings
            s = get_settings()
            self.api_key = getattr(s, 'mailgun_api_key', '')
            self.domain  = getattr(s, 'mailgun_domain', 'mg.landverify.ng')
            self.from_   = getattr(s, 'from_email', 'noreply@landverify.ng')
        except Exception:
            self.api_key = ''; self.domain = ''; self.from_ = 'noreply@landverify.ng'

    async def _send(self, to: str, subject: str, html: str) -> bool:
        if not self.api_key:
            logger.info(f"[EMAIL STUB] To: {to} | Subject: {subject}")
            return True
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"https://api.mailgun.net/v3/{self.domain}/messages",
                auth=("api", self.api_key),
                data={"from": self.from_, "to": to, "subject": subject, "html": html},
            )
            if r.status_code != 200:
                logger.error(f"Mailgun error {r.status_code}: {r.text}")
                return False
            return True

    async def send_welcome(self, email: str, name: str):
        await self._send(email, "Welcome to LandVerify",
            f"<h2>Welcome, {name}!</h2><p>You can now verify land documents and protect yourself from fraud.</p>")

    async def send_email_verification(self, email: str, token: str):
        url = f"https://app.landverify.ng/verify-email/{token}"
        await self._send(email, "Verify your LandVerify email",
            f"<p>Click below to verify your email address:</p><a href='{url}'>Verify Email</a>")

    async def send_password_reset(self, email: str, token: str):
        url = f"https://app.landverify.ng/reset-password/{token}"
        await self._send(email, "Reset your LandVerify password",
            f"<p>Click below to reset your password. This link expires in 1 hour.</p><a href='{url}'>Reset Password</a>")

    async def send_fraud_alert(self, email: str, property_address: str, alert_title: str, severity: str):
        color = {"critical": "#8B1A1A", "high": "#B7600A", "medium": "#6B5600"}.get(severity, "#333")
        await self._send(email, f"🚨 Fraud Alert: {alert_title}",
            f"""<div style='font-family:sans-serif;'>
            <h2 style='color:{color}'>Fraud Alert Detected</h2>
            <p><strong>Property:</strong> {property_address}</p>
            <p><strong>Alert:</strong> {alert_title}</p>
            <p><strong>Severity:</strong> {severity.upper()}</p>
            <p>Log in to LandVerify to take action: <a href='https://app.landverify.ng/alerts'>View Alert</a></p>
            </div>""")

    async def send_verification_complete(self, email: str, property_address: str, score: float, level: str):
        color = {"safe": "#1E6B45", "caution": "#B7600A", "danger": "#8B1A1A"}.get(level, "#333")
        await self._send(email, f"Verification Complete — Trust Score {score:.0f}",
            f"""<div style='font-family:sans-serif;'>
            <h2>Verification Complete</h2>
            <p><strong>Property:</strong> {property_address}</p>
            <p><strong>Trust Score:</strong> <span style='color:{color};font-size:24px;font-weight:bold;'>{score:.0f}/100</span></p>
            <p><a href='https://app.landverify.ng/verifications'>View Full Report</a></p>
            </div>""")

email_service = EmailService()
