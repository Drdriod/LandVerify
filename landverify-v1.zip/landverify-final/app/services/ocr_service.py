"""
LandVerify — OCR Service
Extracts text from uploaded land documents (PDF, PNG, JPG).
Uses Tesseract OCR with preprocessing for Nigerian document quality.
"""
import io
import re
import logging
from pathlib import Path
from typing import Optional

try:
    import pytesseract
    from PIL import Image, ImageFilter, ImageEnhance
    from pdf2image import convert_from_bytes
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

from app.models.document import DocumentMetadata, DocumentType, NigerianState

logger = logging.getLogger(__name__)


class OCRService:
    """
    Handles text extraction from Nigerian land documents.

    Supports:
    - PDF documents (multi-page)
    - Scanned images (JPG, PNG)
    - Low-quality / aged document preprocessing
    """

    # Nigerian document patterns for metadata extraction
    PATTERNS = {
        "file_number": [
            r"(?:File|Ref|Reference|No\.?)\s*[:\-]?\s*([A-Z]{1,3}/[A-Z]{1,3}/\d{4}/\d{3,8})",
            r"(?:LG|AB|RV|OG|KN|EN|DL|OY)/[A-Z]{2,4}/\d{4}/\d{3,8}",
        ],
        "issue_date": [
            r"(?:dated?|issued?|signed?)\s+(?:this\s+)?(\d{1,2}(?:st|nd|rd|th)?\s+\w+\s+\d{4})",
            r"(\d{1,2}[/\-]\d{1,2}[/\-]\d{4})",
            r"(\d{4}[/\-]\d{1,2}[/\-]\d{1,2})",
        ],
        "stamp_duty": [
            r"(?:stamp\s+duty|FIRS)\s+(?:ref|reference|receipt)?\s*[:\-]?\s*([A-Z0-9/\-]{8,20})",
        ],
        "plot_number": [
            r"(?:plot|lot)\s+(?:no\.?)?\s*([A-Z0-9\-/]+)",
        ],
        "survey_plan": [
            r"(?:survey\s+plan|S\.P\.?)\s+(?:no\.?)?\s*([A-Z]{1,3}\d{3,8}/\d{4})",
        ],
        "land_size": [
            r"(\d+(?:\.\d+)?)\s*(?:square\s+met(?:res?|ers?)|sq\.?\s*m|hectares?|acres?|sqm)",
        ],
        "coordinates": [
            r"(?:latitude|lat\.?)\s*[:\-]?\s*(\d+°\d+'\d+(?:\.\d+)?\"?[NS])",
            r"(\d+\.\d{4,}[NS]?\s*,?\s*\d+\.\d{4,}[EW]?)",
        ],
    }

    NIGERIAN_GOVERNORS = {
        "lagos": ["Fashola", "Ambode", "Sanwo-Olu"],
        "abuja_fct": ["Okonkwo", "Bello"],
        "rivers": ["Amaechi", "Wike", "Fubara"],
        "ogun": ["Amosun", "Abiodun"],
    }

    def preprocess_image(self, image: "Image.Image") -> "Image.Image":
        """
        Enhance image quality for better OCR accuracy on Nigerian documents.
        Many Nigerian land documents are aged, faded, or low-resolution scans.
        """
        # Convert to grayscale
        image = image.convert("L")

        # Increase contrast — aged documents tend to be faded
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(2.0)

        # Sharpen — improves edge detection on stamps and signatures
        image = image.filter(ImageFilter.SHARPEN)

        # Denoise
        image = image.filter(ImageFilter.MedianFilter(size=3))

        return image

    async def extract_text_from_file(
        self,
        file_bytes: bytes,
        filename: str
    ) -> str:
        """
        Main entry point. Extracts raw text from a document file.
        Handles both PDFs and images.
        """
        if not OCR_AVAILABLE:
            logger.warning("OCR libraries not available — returning mock text for development")
            return self._mock_document_text()

        file_ext = Path(filename).suffix.lower()

        if file_ext == ".pdf":
            return await self._extract_from_pdf(file_bytes)
        elif file_ext in [".jpg", ".jpeg", ".png", ".tiff", ".bmp"]:
            return await self._extract_from_image(file_bytes)
        else:
            raise ValueError(f"Unsupported file type: {file_ext}")

    async def _extract_from_pdf(self, pdf_bytes: bytes) -> str:
        """Convert PDF pages to images then OCR each page."""
        try:
            images = convert_from_bytes(pdf_bytes, dpi=300)
            all_text = []

            for page_num, image in enumerate(images):
                logger.info(f"Processing PDF page {page_num + 1}/{len(images)}")
                processed = self.preprocess_image(image)
                text = pytesseract.image_to_string(
                    processed,
                    config="--oem 3 --psm 6 -l eng"
                )
                all_text.append(f"=== PAGE {page_num + 1} ===\n{text}")

            return "\n\n".join(all_text)

        except Exception as e:
            logger.error(f"PDF extraction failed: {e}")
            raise

    async def _extract_from_image(self, image_bytes: bytes) -> str:
        """OCR a single image file."""
        try:
            image = Image.open(io.BytesIO(image_bytes))
            processed = self.preprocess_image(image)
            return pytesseract.image_to_string(
                processed,
                config="--oem 3 --psm 6 -l eng"
            )
        except Exception as e:
            logger.error(f"Image extraction failed: {e}")
            raise

    def parse_metadata(self, raw_text: str, state: NigerianState) -> DocumentMetadata:
        """
        Parse structured metadata from raw OCR text using regex patterns
        tuned for Nigerian land document formats.
        """
        text_lower = raw_text.lower()
        metadata = DocumentMetadata(raw_text=raw_text)

        # Document type detection
        metadata.document_type = self._detect_document_type(text_lower)

        # Extract file number
        metadata.file_number = self._extract_pattern(raw_text, "file_number")

        # Extract dates
        metadata.issue_date = self._extract_pattern(raw_text, "issue_date")

        # Extract stamp duty reference
        metadata.stamp_duty_reference = self._extract_pattern(raw_text, "stamp_duty")

        # Extract plot number
        metadata.plot_number = self._extract_pattern(text_lower, "plot_number")

        # Extract survey plan number
        metadata.survey_plan_number = self._extract_pattern(raw_text, "survey_plan")

        # Extract land size
        metadata.land_size = self._extract_pattern(text_lower, "land_size")

        # Extract coordinates
        metadata.coordinates = self._extract_pattern(raw_text, "coordinates")

        # Extract governor name (validates document period)
        metadata.governor_name = self._extract_governor(
            raw_text,
            state.value if state else None
        )

        # Extract owner name (look for "GRANTED TO" or "THIS DEED" patterns)
        metadata.owner_name = self._extract_owner_name(raw_text)

        return metadata

    def _detect_document_type(self, text: str) -> Optional[DocumentType]:
        """Detect document type from text content."""
        type_keywords = {
            DocumentType.C_OF_O: ["certificate of occupancy", "c of o", "c.of.o"],
            DocumentType.DEED_OF_ASSIGNMENT: ["deed of assignment", "this deed of assignment"],
            DocumentType.SURVEY_PLAN: ["survey plan", "surveyor general", "plan no."],
            DocumentType.GOVERNORS_CONSENT: ["governor's consent", "governor consent", "consent"],
            DocumentType.RIGHT_OF_OCCUPANCY: ["right of occupancy", "statutory right"],
            DocumentType.EXCISION: ["excision", "community land", "excised"],
            DocumentType.DEED_OF_GIFT: ["deed of gift", "freely given", "gift"],
            DocumentType.PROBATE: ["probate", "letters of administration", "deceased estate"],
        }
        for doc_type, keywords in type_keywords.items():
            if any(kw in text for kw in keywords):
                return doc_type
        return None

    def _extract_pattern(self, text: str, pattern_key: str) -> Optional[str]:
        """Try all patterns for a field and return first match."""
        patterns = self.PATTERNS.get(pattern_key, [])
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1) if match.lastindex else match.group(0)
        return None

    def _extract_governor(self, text: str, state: Optional[str]) -> Optional[str]:
        """Extract governor name that signed the document."""
        if not state:
            return None
        governors = self.NIGERIAN_GOVERNORS.get(state, [])
        for governor in governors:
            if governor.lower() in text.lower():
                return governor
        # Generic search
        match = re.search(
            r"(?:governor|signed by|executive governor)\s+(?:of\s+\w+\s+state\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3})",
            text, re.IGNORECASE
        )
        return match.group(1) if match else None

    def _extract_owner_name(self, text: str) -> Optional[str]:
        """Extract the named owner/grantee from the document."""
        patterns = [
            r"(?:granted to|conveyed to|assigned to|in favour of)\s+([A-Z][A-Za-z\s&\.]+?)(?:\s+of|\s+residing|\s+hereinafter|,|\n)",
            r"(?:THIS DEED|KNOW ALL MEN)\s+.*?between\s+([A-Z][A-Za-z\s&\.]+?)(?:\s+of|\s+\(|,)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()
        return None

    def _mock_document_text(self) -> str:
        """
        Mock OCR output for development/testing when Tesseract is not installed.
        Simulates a real Nigerian C of O document.
        """
        return """
        LAGOS STATE GOVERNMENT
        MINISTRY OF LANDS, HOUSING AND URBAN DEVELOPMENT

        CERTIFICATE OF OCCUPANCY
        File No: LG/BC/2021/004471
        Dated this 15th day of March, 2021

        KNOW ALL MEN BY THESE PRESENTS that the Governor of Lagos State, under the
        powers conferred by Section 9 of the Land Use Act, 1978, hereby grants to

        CHUKWUEMEKA OBI & ASSOCIATES LIMITED
        (RC No: 1234567)
        of 14 Admiralty Way, Lekki Phase 1, Lagos

        a CERTIFICATE OF OCCUPANCY in respect of ALL THAT piece and parcel of land
        situate and lying at Plot 14B, Admiralty Way, Lekki Phase 1, Lagos State,
        Nigeria measuring approximately 450 square metres.

        Survey Plan No: LS/3215/2021
        Stamp Duty Reference: SD/2021/449821

        Coordinates: 6°4412.3N 3°2741.8E

        Signed by the Executive Governor of Lagos State
        Mr. Babajide Sanwo-Olu
        GOVERNOR, LAGOS STATE

        Registered at the Land Registry, Alausa, Ikeja
        """


# Singleton instance
ocr_service = OCRService()
