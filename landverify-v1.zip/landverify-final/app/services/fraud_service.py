"""
LandVerify — Fraud Detection Service
Rule-based fraud pattern detection that works ALONGSIDE Claude AI analysis.

This layer catches deterministic red flags before sending to Claude,
making the overall system faster and cheaper to run.
"""
import re
import logging
from typing import List, Optional
from datetime import datetime

from app.models.document import (
    FraudFlag, FraudSeverity, DocumentMetadata,
    VerificationRequest, DocumentType
)

logger = logging.getLogger(__name__)


class FraudDetectionService:
    """
    Rule-based fraud detection engine for Nigerian land documents.

    Works in two layers:
    1. Fast rule-based checks (this service) — catches obvious red flags instantly
    2. Claude AI deep analysis (claude_service) — catches subtle and complex patterns

    Together they provide a comprehensive fraud detection system.
    """

    # Known fraudulent file number prefixes (from historical fraud cases)
    BLACKLISTED_FILE_PREFIXES = [
        "FAKE/", "TEST/", "DEMO/",
    ]

    # Suspicious agent patterns in additional notes
    SUSPICIOUS_PHRASES = [
        "pay cash only", "no receipt", "urgent sale", "fleeing country",
        "overseas seller", "power of attorney only", "no inspection",
        "family emergency", "sell quickly", "no questions",
    ]

    # Nigerian states and their valid file number state codes
    STATE_FILE_CODES = {
        "lagos":      ["LG", "LA", "LAG"],
        "abuja_fct":  ["AB", "ABJ", "FCT"],
        "rivers":     ["RV", "RIV", "PH"],
        "ogun":       ["OG", "OGN"],
        "kano":       ["KN", "KAN"],
        "enugu":      ["EN", "ENU"],
        "delta":      ["DL", "DEL"],
        "oyo":        ["OY", "OYO"],
    }

    # Minimum year for valid C of O (Land Use Act enacted in 1978)
    LAND_USE_ACT_YEAR = 1978

    def run_all_checks(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest,
        additional_notes: Optional[str] = None
    ) -> List[FraudFlag]:
        """
        Run all rule-based fraud checks and return list of detected flags.
        """
        flags: List[FraudFlag] = []

        # Run each check
        flags.extend(self._check_file_number(metadata, request))
        flags.extend(self._check_date_validity(metadata))
        flags.extend(self._check_state_code_mismatch(metadata, request))
        flags.extend(self._check_blacklisted_patterns(metadata))
        flags.extend(self._check_suspicious_notes(additional_notes))
        flags.extend(self._check_document_consistency(metadata, request))
        flags.extend(self._check_land_use_act_compliance(metadata))

        logger.info(f"Rule-based fraud check complete — {len(flags)} flags detected")
        return flags

    def _check_file_number(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest
    ) -> List[FraudFlag]:
        """Validate file number format and content."""
        flags = []

        if not metadata.file_number and not request.file_number:
            flags.append(FraudFlag(
                flag_id="no_file_number",
                severity=FraudSeverity.MEDIUM,
                title="No File Number Found",
                description=(
                    "No file number was detected in the document or provided by the user. "
                    "All legitimate Nigerian land title documents must bear a unique file number "
                    "assigned by the state Land Registry."
                ),
                recommendation=(
                    "Request the file number from the seller and verify it directly at the "
                    f"{request.state.value.replace('_', ' ').title()} State Land Registry."
                ),
                confidence=0.85
            ))
            return flags

        file_num = metadata.file_number or request.file_number or ""

        # Check for blacklisted prefixes
        for prefix in self.BLACKLISTED_FILE_PREFIXES:
            if file_num.upper().startswith(prefix):
                flags.append(FraudFlag(
                    flag_id="blacklisted_file_prefix",
                    severity=FraudSeverity.CRITICAL,
                    title="Blacklisted File Number Detected",
                    description=f"The file number '{file_num}' contains a pattern associated with known fraudulent documents.",
                    recommendation="Do NOT proceed. Report this document to the Nigeria Police Force Economic and Financial Crimes Commission (EFCC).",
                    confidence=0.99
                ))

        # Validate format: XX/XX/YYYY/NNNNNN
        valid_pattern = r"^[A-Z]{1,4}/[A-Z]{1,4}/\d{4}/\d{3,8}$"
        if not re.match(valid_pattern, file_num.strip().upper()):
            flags.append(FraudFlag(
                flag_id="invalid_file_number_format",
                severity=FraudSeverity.HIGH,
                title="File Number Format Invalid",
                description=(
                    f"The file number '{file_num}' does not match the standard Nigerian land registry format "
                    f"(e.g., LG/BC/2021/004471). This may indicate a forged or altered document."
                ),
                recommendation="Have a qualified property lawyer verify this file number directly at the state registry.",
                confidence=0.80
            ))

        return flags

    def _check_date_validity(self, metadata: DocumentMetadata) -> List[FraudFlag]:
        """Check document dates for anomalies."""
        flags = []

        if not metadata.issue_date:
            return flags

        # Try to extract year from issue date string
        year_match = re.search(r"\b(19|20)\d{2}\b", metadata.issue_date)
        if not year_match:
            return flags

        doc_year = int(year_match.group(0))
        current_year = datetime.now().year

        if doc_year < self.LAND_USE_ACT_YEAR:
            flags.append(FraudFlag(
                flag_id="pre_land_use_act",
                severity=FraudSeverity.HIGH,
                title="Document Pre-dates Land Use Act",
                description=(
                    f"This document is dated {doc_year}, before the Land Use Act of 1978. "
                    "While customary rights may pre-date the Act, any formal C of O or "
                    "Deed of Assignment should reference modern legislation."
                ),
                recommendation="Consult a property lawyer to clarify the legal basis of this title.",
                confidence=0.75
            ))

        if doc_year > current_year:
            flags.append(FraudFlag(
                flag_id="future_date",
                severity=FraudSeverity.CRITICAL,
                title="Document is Future-Dated",
                description=(
                    f"This document bears a date of {doc_year}, which is in the future. "
                    "This is a clear indicator of document forgery."
                ),
                recommendation="Do NOT proceed with this transaction. This document is fraudulent.",
                confidence=0.99
            ))

        return flags

    def _check_state_code_mismatch(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest
    ) -> List[FraudFlag]:
        """Check if file number state code matches declared state."""
        flags = []

        file_num = metadata.file_number or request.file_number
        if not file_num:
            return flags

        state = request.state.value
        valid_codes = self.STATE_FILE_CODES.get(state, [])
        if not valid_codes:
            return flags

        file_prefix = file_num.split("/")[0].upper()
        if file_prefix and file_prefix not in valid_codes:
            flags.append(FraudFlag(
                flag_id="state_code_mismatch",
                severity=FraudSeverity.HIGH,
                title="State Code Mismatch in File Number",
                description=(
                    f"The file number prefix '{file_prefix}' does not match the declared state "
                    f"({state.replace('_', ' ').title()}). "
                    f"Expected prefixes for this state: {', '.join(valid_codes)}."
                ),
                recommendation=(
                    "Verify which state this property is registered in. If in Lagos, "
                    "the file number should begin with LG or LA."
                ),
                confidence=0.85
            ))

        return flags

    def _check_blacklisted_patterns(self, metadata: DocumentMetadata) -> List[FraudFlag]:
        """Check document text for known fraud language patterns."""
        flags = []

        if not metadata.raw_text:
            return flags

        text_lower = metadata.raw_text.lower()

        # Check for cut-and-paste evidence (repeated blocks of text)
        words = text_lower.split()
        if len(words) > 50:
            word_chunks = [" ".join(words[i:i+10]) for i in range(0, len(words)-10, 10)]
            unique_chunks = set(word_chunks)
            if len(unique_chunks) < len(word_chunks) * 0.7:
                flags.append(FraudFlag(
                    flag_id="repeated_content",
                    severity=FraudSeverity.MEDIUM,
                    title="Repeated Content Detected",
                    description="The document contains unusual repetitions of text blocks, which may indicate cut-and-paste document manipulation.",
                    recommendation="Have this document physically inspected by a certified surveyor and property lawyer.",
                    confidence=0.60
                ))

        # Check for alteration markers
        alteration_keywords = ["correction", "amended", "deleted", "struck out", "altered"]
        found_alterations = [kw for kw in alteration_keywords if kw in text_lower]
        if found_alterations:
            flags.append(FraudFlag(
                flag_id="alteration_markers",
                severity=FraudSeverity.MEDIUM,
                title="Document Alteration Language Found",
                description=f"The document contains language suggesting alterations: {', '.join(found_alterations)}. This may indicate the document has been modified after official signing.",
                recommendation="Request a certified true copy directly from the Land Registry to compare against this version.",
                confidence=0.65
            ))

        return flags

    def _check_suspicious_notes(self, additional_notes: Optional[str]) -> List[FraudFlag]:
        """Check user-provided notes for red flag phrases."""
        flags = []

        if not additional_notes:
            return flags

        notes_lower = additional_notes.lower()
        found_phrases = [p for p in self.SUSPICIOUS_PHRASES if p in notes_lower]

        if found_phrases:
            flags.append(FraudFlag(
                flag_id="suspicious_transaction_context",
                severity=FraudSeverity.HIGH,
                title="Suspicious Transaction Context",
                description=(
                    f"The transaction context contains phrases associated with common land scams: "
                    f"'{', '.join(found_phrases)}'. "
                    "Pressure to act quickly, cash-only requirements, and overseas sellers are "
                    "classic warning signs of Nigerian land fraud."
                ),
                recommendation=(
                    "Slow down. Do not allow anyone to pressure you into a quick decision. "
                    "Legitimate sellers do not refuse receipts or proper documentation. "
                    "Consult a property lawyer before any payment."
                ),
                confidence=0.80
            ))

        return flags

    def _check_document_consistency(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest
    ) -> List[FraudFlag]:
        """Cross-check declared details against document metadata."""
        flags = []

        # Check owner name consistency
        if metadata.owner_name and request.owner_name:
            declared = request.owner_name.lower().strip()
            extracted = metadata.owner_name.lower().strip()

            # Fuzzy match — names should share significant words
            declared_words = set(declared.split())
            extracted_words = set(extracted.split())
            common_words = declared_words & extracted_words

            if len(common_words) == 0 and len(declared_words) > 1:
                flags.append(FraudFlag(
                    flag_id="owner_name_mismatch",
                    severity=FraudSeverity.HIGH,
                    title="Owner Name Mismatch",
                    description=(
                        f"The declared owner '{request.owner_name}' does not match the name "
                        f"found in the document '{metadata.owner_name}'. "
                        "This discrepancy could indicate a forged document or an illegal transfer."
                    ),
                    recommendation=(
                        "Do not proceed until the correct owner name is confirmed. "
                        "Obtain the seller's valid ID and compare against the document."
                    ),
                    confidence=0.85
                ))

        return flags

    def _check_land_use_act_compliance(self, metadata: DocumentMetadata) -> List[FraudFlag]:
        """Check for Land Use Act compliance markers."""
        flags = []

        if not metadata.raw_text:
            return flags

        text_lower = metadata.raw_text.lower()

        # C of O must reference the Land Use Act
        if metadata.document_type == DocumentType.C_OF_O:
            if "land use act" not in text_lower and "land use decree" not in text_lower:
                flags.append(FraudFlag(
                    flag_id="missing_land_use_act_reference",
                    severity=FraudSeverity.MEDIUM,
                    title="Land Use Act Not Referenced",
                    description=(
                        "A legitimate Certificate of Occupancy must cite the Land Use Act of 1978 "
                        "as the legal authority. This document does not contain this reference, "
                        "which raises questions about its authenticity."
                    ),
                    recommendation="Compare this document with a sample C of O from the Lagos State Land Registry website.",
                    confidence=0.70
                ))

        return flags


# Singleton instance
fraud_detection_service = FraudDetectionService()
