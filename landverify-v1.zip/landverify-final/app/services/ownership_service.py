"""
LandVerify — Ownership Chain Service
Tracks, validates, and reconstructs property ownership history.
"""
import uuid
import logging
from typing import List, Optional
from app.models.document import (
    OwnershipChain, OwnershipRecord,
    DocumentMetadata, VerificationRequest
)

logger = logging.getLogger(__name__)


class OwnershipService:
    """
    Manages the complete ownership chain of a property.

    Key functions:
    - Reconstruct chain from document text (via Claude AI)
    - Validate chain continuity (no gaps, no duplicates)
    - Calculate chain integrity score
    - Flag suspicious transfer patterns
    """

    # Maximum years between transfers before flagging a gap
    MAX_TRANSFER_GAP_YEARS = 30

    # Suspicious transfer patterns
    SUSPICIOUS_TRANSFER_TYPES = [
        "unregistered transfer",
        "informal sale",
        "verbal agreement",
        "disputed",
        "unknown transfer",
    ]

    def build_from_claude_response(
        self,
        claude_ownership_data: dict,
        property_id: str
    ) -> OwnershipChain:
        """
        Converts Claude AI's ownership analysis into a structured OwnershipChain object.
        """
        records_data = claude_ownership_data.get("records", [])
        records = []

        for r in records_data:
            record = OwnershipRecord(
                year=r.get("year", "Unknown"),
                owner_name=r.get("owner_name", "Unknown"),
                transaction_type=r.get("transaction_type", "Unknown"),
                consideration=r.get("consideration"),
                instrument=r.get("instrument"),
                registered=r.get("registered", True),
                flagged=r.get("flagged", False),
                flag_reason=r.get("flag_reason"),
            )
            records.append(record)

        chain_integrity = float(claude_ownership_data.get("chain_integrity", 0.5))
        has_gaps = bool(claude_ownership_data.get("has_gaps", False))
        has_disputes = bool(claude_ownership_data.get("has_disputes", False))

        # Run our own additional validation
        additional_flags = self._validate_chain(records)
        if additional_flags:
            has_gaps = has_gaps or any("gap" in f.lower() for f in additional_flags)
            # Reduce integrity score for each issue found
            chain_integrity = max(0.1, chain_integrity - (len(additional_flags) * 0.08))

        return OwnershipChain(
            property_id=property_id,
            total_owners=len(records),
            chain_integrity=round(chain_integrity, 3),
            has_gaps=has_gaps,
            has_disputes=has_disputes,
            records=records,
            analysis_summary=claude_ownership_data.get(
                "analysis_summary",
                "Ownership chain analysis completed."
            )
        )

    def _validate_chain(self, records: List[OwnershipRecord]) -> List[str]:
        """
        Run additional deterministic validation on the ownership chain.
        Returns list of issue descriptions found.
        """
        issues = []

        if not records:
            issues.append("No ownership records found — chain cannot be established")
            return issues

        # Check for unregistered transfers
        unregistered = [r for r in records if not r.registered]
        if unregistered:
            for r in unregistered:
                issues.append(
                    f"Unregistered transfer in {r.year} to {r.owner_name} — "
                    "this transfer was not recorded at the Land Registry"
                )

        # Check for gaps between transfers
        years = []
        for r in records:
            import re
            year_match = re.search(r"\b(19|20)\d{2}\b", r.year)
            if year_match:
                years.append(int(year_match.group(0)))

        if len(years) >= 2:
            for i in range(1, len(years)):
                gap = years[i] - years[i - 1]
                if gap > self.MAX_TRANSFER_GAP_YEARS:
                    issues.append(
                        f"Large ownership gap: {gap} years between {years[i-1]} and {years[i]} "
                        "with no recorded transfer — ownership during this period is unclear"
                    )

        # Check for suspicious transfer descriptions
        for r in records:
            transaction_lower = r.transaction_type.lower()
            for suspicious in self.SUSPICIOUS_TRANSFER_TYPES:
                if suspicious in transaction_lower:
                    issues.append(
                        f"Suspicious transfer type in {r.year}: '{r.transaction_type}' — "
                        "informal or unverified transfers create title risk"
                    )

        # Check for duplicate owners (same property sold twice to same person)
        owner_years = {}
        for r in records:
            name = r.owner_name.lower().strip()
            if name in owner_years:
                issues.append(
                    f"Owner '{r.owner_name}' appears multiple times in the chain — "
                    "potential evidence of title cycling or circular ownership fraud"
                )
            owner_years[name] = r.year

        return issues

    def calculate_chain_integrity_score(self, chain: OwnershipChain) -> float:
        """
        Recalculate integrity score from the chain object directly.
        Used for Trust Score input.
        """
        base_score = chain.chain_integrity

        # Bonus: well-documented chain with many verified transfers
        if chain.total_owners >= 2 and not chain.has_gaps:
            base_score = min(1.0, base_score + 0.05)

        # Penalty: gaps or disputes
        if chain.has_gaps:
            base_score = max(0.1, base_score - 0.15)
        if chain.has_disputes:
            base_score = max(0.1, base_score - 0.20)

        # Penalty: unregistered transfers
        unregistered_count = sum(1 for r in chain.records if not r.registered)
        base_score = max(0.1, base_score - (unregistered_count * 0.10))

        # Penalty: flagged records
        flagged_count = sum(1 for r in chain.records if r.flagged)
        base_score = max(0.1, base_score - (flagged_count * 0.12))

        return round(base_score, 3)

    def generate_mock_chain(
        self,
        property_address: str,
        owner_name: str,
        state: str
    ) -> OwnershipChain:
        """
        Generate a realistic mock ownership chain for development/testing.
        Represents a typical Lagos property with a clean history.
        """
        records = [
            OwnershipRecord(
                year="1985",
                owner_name=f"{state.upper()} State Government",
                transaction_type="Original Allocation",
                consideration="N/A — Government Allocation",
                instrument="Government Notice No. 142",
                registered=True,
                flagged=False,
            ),
            OwnershipRecord(
                year="1991",
                owner_name="Chief Emmanuel Adeyemi",
                transaction_type="Purchase",
                consideration="₦85,000",
                instrument="Deed of Assignment No. 24, Page 18, Volume 3",
                registered=True,
                flagged=False,
            ),
            OwnershipRecord(
                year="2005",
                owner_name="Adeyemi Family Estate",
                transaction_type="Inheritance",
                consideration="N/A — Probate Ref: LAG/PRO/2005/0112",
                instrument="Letters of Administration",
                registered=True,
                flagged=False,
            ),
            OwnershipRecord(
                year="2019",
                owner_name=owner_name,
                transaction_type="Purchase",
                consideration="₦45,000,000",
                instrument="Deed of Assignment — Registered",
                registered=True,
                flagged=False,
            ),
        ]

        return OwnershipChain(
            property_id=str(uuid.uuid4()),
            total_owners=len(records),
            chain_integrity=0.87,
            has_gaps=False,
            has_disputes=False,
            records=records,
            analysis_summary=(
                "The ownership chain for this property is well-documented with 4 recorded owners "
                "since the original government allocation in 1985. All transfers are registered "
                "and legally documented. The chain shows no gaps or disputes. This represents a "
                "healthy title history and supports a high Trust Score contribution."
            )
        )


# Singleton instance
ownership_service = OwnershipService()
