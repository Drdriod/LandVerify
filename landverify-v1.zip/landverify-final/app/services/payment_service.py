"""
LandVerify — Payment Service (Paystack)
Nigeria's leading payment gateway.
Handles plan upgrades and per-verification purchases.

Plans:
  Free       → 3 verifications  → ₦0
  Individual → 50/month         → ₦5,000/month
  Pro        → 200/month        → ₦15,000/month
  Enterprise → Unlimited + API  → ₦50,000/month
"""
import logging, hashlib, hmac, httpx
from typing import Optional

logger = logging.getLogger(__name__)

PLANS = {
    "individual": {"price_kobo": 500000,  "verifications": 50,  "name": "Individual"},
    "professional":{"price_kobo": 1500000, "verifications": 200, "name": "Professional"},
    "enterprise":  {"price_kobo": 5000000, "verifications": -1,  "name": "Enterprise"},
}
PAY_PER_VERIFY_KOBO = 50000  # ₦500 per single verification


class PaystackService:
    BASE = "https://api.paystack.co"

    def __init__(self):
        try:
            from app.config import get_settings
            s = get_settings()
            self.secret = getattr(s, 'paystack_secret_key', '')
        except Exception:
            self.secret = ''

    def _headers(self):
        return {"Authorization": f"Bearer {self.secret}", "Content-Type": "application/json"}

    async def initialize_transaction(self, email: str, amount_kobo: int,
                                     metadata: dict, callback_url: str) -> Optional[dict]:
        """Create a Paystack payment link. Returns {authorization_url, reference}."""
        if not self.secret:
            # Dev stub — return fake auth URL
            import uuid
            ref = f"LV_{uuid.uuid4().hex[:12].upper()}"
            logger.info(f"[PAYSTACK STUB] Init payment: {email} ₦{amount_kobo/100:.0f} ref={ref}")
            return {"authorization_url": f"https://checkout.paystack.com/{ref}", "reference": ref}

        async with httpx.AsyncClient() as client:
            r = await client.post(f"{self.BASE}/transaction/initialize",
                headers=self._headers(), json={
                    "email": email, "amount": amount_kobo,
                    "metadata": metadata, "callback_url": callback_url,
                    "currency": "NGN",
                })
            if r.status_code == 200:
                data = r.json()["data"]
                return {"authorization_url": data["authorization_url"], "reference": data["reference"]}
            logger.error(f"Paystack init error: {r.text}")
            return None

    async def verify_transaction(self, reference: str) -> Optional[dict]:
        """Verify a payment after Paystack callback. Returns status + amount."""
        if not self.secret:
            logger.info(f"[PAYSTACK STUB] Verify: {reference}")
            return {"status": "success", "amount": 500000, "email": "user@example.com"}

        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.BASE}/transaction/verify/{reference}", headers=self._headers())
            if r.status_code == 200:
                data = r.json()["data"]
                return {"status": data["status"], "amount": data["amount"], "email": data["customer"]["email"]}
            return None

    def verify_webhook(self, payload: bytes, signature: str) -> bool:
        """Verify Paystack webhook signature (HMAC-SHA512)."""
        expected = hmac.new(self.secret.encode(), payload, hashlib.sha512).hexdigest()
        return hmac.compare_digest(expected, signature)

    async def create_plan_payment(self, user_email: str, plan: str) -> Optional[dict]:
        plan_data = PLANS.get(plan)
        if not plan_data:
            return None
        return await self.initialize_transaction(
            email=user_email, amount_kobo=plan_data["price_kobo"],
            metadata={"plan": plan, "type": "subscription"},
            callback_url="https://app.landverify.ng/payment/callback",
        )

    async def create_single_verification_payment(self, user_email: str) -> Optional[dict]:
        return await self.initialize_transaction(
            email=user_email, amount_kobo=PAY_PER_VERIFY_KOBO,
            metadata={"type": "single_verification"},
            callback_url="https://app.landverify.ng/payment/callback",
        )

paystack = PaystackService()
