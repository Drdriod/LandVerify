"""
LandVerify — Claude AI Service
The intelligence brain of LandVerify.
Uses Claude API to analyse documents, detect fraud, and generate human-readable reports.
"""
import json
import logging
from typing import Optional
import anthropic

from app.config import get_settings
from app.models.document import (
    DocumentMetadata, VerificationRequest,
    FraudFlag, FraudSeverity, OwnershipChain, OwnershipRecord
)

logger = logging.getLogger(__name__)
settings = get_settings()


class ClaudeService:
    """
    Wraps the Anthropic Claude API for all AI-powered analysis in LandVerify.

    Responsibilities:
    1. Document authenticity analysis
    2. Fraud pattern detection and explanation
    3. Ownership chain reconstruction from text
    4. Human-readable risk summaries
    5. Recommendations for buyers, lawyers, banks
    """

    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
        self.model = settings.claude_model

    # ─────────────────────────────────────────────
    # 1. DOCUMENT AUTHENTICITY ANALYSIS
    # ─────────────────────────────────────────────

    async def analyse_document_authenticity(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest
    ) -> dict:
        """
        Analyses document text and metadata for authenticity indicators.
        Returns structured JSON with scores and findings.
        """
        prompt = f"""You are LandVerify's document authentication expert specialising in Nigerian land documents.

Analyse the following Nigerian land document and return a JSON response with your findings.

DOCUMENT DETAILS:
- Type: {request.document_type.value}
- State: {request.state.value}
- Declared Owner: {request.owner_name}
- Property Address: {request.property_address}
- File Number: {request.file_number or 'Not provided'}
- Extracted Text:
{metadata.raw_text or 'No text extracted'}

EXTRACTED METADATA:
- Document Type Detected: {metadata.document_type}
- File Number Found: {metadata.file_number}
- Issue Date: {metadata.issue_date}
- Stamp Duty Ref: {metadata.stamp_duty_reference}
- Governor Name: {metadata.governor_name}
- Survey Plan: {metadata.survey_plan_number}
- Land Size: {metadata.land_size}
- Coordinates: {metadata.coordinates}

Evaluate the following authenticity checks and return ONLY valid JSON (no markdown, no explanation):

{{
  "authenticity_score": <float 0.0-1.0>,
  "checks": [
    {{
      "check_id": "format_validity",
      "label": "Document Format Valid",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.20
    }},
    {{
      "check_id": "stamp_duty",
      "label": "Stamp Duty Verified",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.15
    }},
    {{
      "check_id": "governor_signature",
      "label": "Governor Signature Period",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.15
    }},
    {{
      "check_id": "document_consistency",
      "label": "Internal Document Consistency",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.20
    }},
    {{
      "check_id": "file_number_format",
      "label": "File Number Format",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.10
    }},
    {{
      "check_id": "survey_plan_present",
      "label": "Survey Plan Referenced",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.10
    }},
    {{
      "check_id": "address_consistency",
      "label": "Address Consistency",
      "status": "pass|fail|warning",
      "detail": "<specific finding>",
      "weight": 0.10
    }}
  ],
  "anomalies_detected": ["<list any suspicious elements found>"],
  "authenticity_summary": "<2-3 sentence summary of document authenticity findings>"
}}

Base your analysis on:
- Nigerian Land Use Act (1978) requirements
- Standard Lagos/Abuja/Rivers State land document formats
- Known fraud patterns in Nigerian real estate
- Internal consistency of dates, names, and references"""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = response.content[0].text.strip()
        return json.loads(raw)

    # ─────────────────────────────────────────────
    # 2. FRAUD PATTERN DETECTION
    # ─────────────────────────────────────────────

    async def detect_fraud_patterns(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest,
        ownership_chain: Optional[list] = None
    ) -> dict:
        """
        Deep fraud analysis using Claude's pattern recognition.
        Identifies specific Nigerian land fraud schemes.
        """
        prompt = f"""You are Nigeria's leading land fraud investigator with 20 years of experience
detecting property fraud schemes across Lagos, Abuja, Rivers, and other states.

Analyse this land transaction for fraud indicators and return ONLY valid JSON.

TRANSACTION DETAILS:
- Document Type: {request.document_type.value}
- State: {request.state.value}
- Owner Name: {request.owner_name}
- Property Address: {request.property_address}
- File Number: {request.file_number or 'Unknown'}
- User Role: {request.user_role.value}
- Additional Notes: {request.additional_notes or 'None'}

DOCUMENT METADATA EXTRACTED:
{json.dumps(metadata.dict(exclude={'raw_text'}), indent=2, default=str)}

KNOWN NIGERIAN LAND FRAUD SCHEMES TO CHECK:
1. Multiple Sales Fraud — same land sold to multiple buyers simultaneously
2. Omo-Onile (Land Guards) — community members extorting buyers after purchase
3. Fake Government Documents — forged C of O, fake stamps
4. Sellers with No Title — selling land they don't legally own
5. Land Banking Fraud — collecting deposits for non-existent projects
6. Excision Fraud — claiming community land has been excised when it hasn't
7. Government Acquisition — selling land already acquired by government
8. Survey Plan Manipulation — fake or altered survey plans
9. File Number Recycling — reusing cancelled file numbers
10. Backdated Documents — forging older dates to establish false ownership

Return ONLY this JSON structure:

{{
  "fraud_risk_level": "low|medium|high|critical",
  "overall_fraud_score": <float 0.0-1.0, higher = more fraudulent>,
  "flags": [
    {{
      "flag_id": "unique_id",
      "severity": "low|medium|high|critical",
      "title": "<fraud flag title>",
      "description": "<specific description of what was detected>",
      "recommendation": "<specific action the user should take>",
      "confidence": <float 0.0-1.0>
    }}
  ],
  "fraud_summary": "<paragraph summarising fraud risk for a non-expert Nigerian>",
  "safe_to_proceed": <boolean>,
  "immediate_actions": ["<list of immediate actions if high risk>"]
}}

If no significant fraud indicators are found, return an empty flags array and low risk level.
Be specific and practical — your output will be read by ordinary Nigerians making the biggest financial decision of their lives."""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = response.content[0].text.strip()
        return json.loads(raw)

    # ─────────────────────────────────────────────
    # 3. OWNERSHIP CHAIN RECONSTRUCTION
    # ─────────────────────────────────────────────

    async def reconstruct_ownership_chain(
        self,
        metadata: DocumentMetadata,
        request: VerificationRequest
    ) -> dict:
        """
        Reconstructs and validates the property's ownership history
        from document text and known patterns.
        """
        prompt = f"""You are a Nigerian property title examiner. Your job is to reconstruct
the ownership history (chain of title) for a property based on available document information.

PROPERTY: {request.property_address}
STATE: {request.state.value}
DOCUMENT TYPE: {request.document_type.value}
CURRENT DECLARED OWNER: {request.owner_name}
FILE NUMBER: {request.file_number or 'Unknown'}
ISSUE DATE: {metadata.issue_date or 'Unknown'}
DOCUMENT TEXT:
{metadata.raw_text or 'No text available'}

Based on this information, reconstruct a plausible ownership chain and identify any gaps or red flags.

Return ONLY valid JSON:

{{
  "chain_integrity": <float 0.0-1.0, 1.0 = complete and clean chain>,
  "has_gaps": <boolean>,
  "has_disputes": <boolean>,
  "total_owners": <integer>,
  "records": [
    {{
      "year": "<year or year range>",
      "owner_name": "<owner name>",
      "transaction_type": "<Original Allocation|Purchase|Inheritance|Gift|Court Order|Other>",
      "consideration": "<price or 'N/A for inheritance'>",
      "instrument": "<document instrument if known>",
      "registered": <boolean>,
      "flagged": <boolean>,
      "flag_reason": "<reason if flagged, null otherwise>"
    }}
  ],
  "chain_gaps": ["<description of any gaps in the chain>"],
  "analysis_summary": "<2-3 paragraph expert summary of the ownership chain integrity>"
}}

If you cannot reconstruct the chain from available information, create a minimal chain
showing only what is known and flag the gaps appropriately.
Be historically accurate about Nigerian governance periods when determining original allocations."""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=2000,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = response.content[0].text.strip()
        return json.loads(raw)

    # ─────────────────────────────────────────────
    # 4. FINAL HUMAN-READABLE REPORT
    # ─────────────────────────────────────────────

    async def generate_verification_report(
        self,
        trust_score: float,
        trust_level: str,
        checks_summary: dict,
        fraud_summary: dict,
        ownership_summary: dict,
        user_role: str,
        property_address: str
    ) -> dict:
        """
        Generates the final plain-English report and recommendations
        tailored to the user's role (buyer, lawyer, bank, developer).
        """
        prompt = f"""You are LandVerify's report writer. Generate a clear, honest, and practical
verification report for a Nigerian property transaction.

VERIFICATION RESULTS:
- Property: {property_address}
- Trust Score: {trust_score}/100
- Trust Level: {trust_level}
- Checks Passed: {checks_summary.get('passed', 0)}
- Checks Failed: {checks_summary.get('failed', 0)}
- Fraud Risk Level: {fraud_summary.get('fraud_risk_level', 'unknown')}
- Ownership Chain Integrity: {ownership_summary.get('chain_integrity', 0) * 100:.0f}%
- Has Ownership Gaps: {ownership_summary.get('has_gaps', False)}
- User Role: {user_role}

Write a report tailored specifically for a {user_role}. Return ONLY valid JSON:

{{
  "executive_summary": "<3-4 sentence plain English summary of the overall verification result>",
  "role_specific_recommendation": "<specific, actionable advice for this {user_role} — what should they do next?>",
  "key_risks": ["<list top 3 key risks if any>"],
  "next_steps": ["<list 3-5 concrete next steps>"],
  "professional_referral": "<which professional they should consult if needed — property lawyer, surveyor, etc.>"
}}

Be direct and honest. Do not soften bad news. A buyer losing their life savings to fraud
is far worse than being told not to proceed with a transaction.
Write as if you are a trusted friend who is an expert in Nigerian real estate law."""

        response = self.client.messages.create(
            model=self.model,
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}]
        )

        raw = response.content[0].text.strip()
        return json.loads(raw)


# Singleton instance
claude_service = ClaudeService()
