"""
LandVerify — Authentication Service
JWT-based auth with refresh tokens, bcrypt password hashing.
"""
import uuid
import secrets
import hashlib
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── Password hashing ────────────────────────────────────────
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# ── JWT config ──────────────────────────────────────────────
ALGORITHM          = "HS256"
ACCESS_TOKEN_MINS  = 30          # Access token: 30 minutes
REFRESH_TOKEN_DAYS = 30          # Refresh token: 30 days


class AuthService:
    """
    Handles all authentication operations for LandVerify.

    Token Strategy:
    - Short-lived JWT access tokens (30 min) for API requests
    - Long-lived refresh tokens (30 days) stored in the database
    - API keys (bcrypt hashed) for B2B integrations
    """

    # ── Password ────────────────────────────────────────────

    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt."""
        return pwd_context.hash(password)

    def verify_password(self, plain: str, hashed: str) -> bool:
        """Verify a plain password against its bcrypt hash."""
        return pwd_context.verify(plain, hashed)

    def validate_password_strength(self, password: str) -> tuple[bool, str]:
        """
        Enforce strong passwords for a platform handling financial transactions.
        Returns (is_valid, error_message).
        """
        if len(password) < 8:
            return False, "Password must be at least 8 characters"
        if not any(c.isupper() for c in password):
            return False, "Password must contain at least one uppercase letter"
        if not any(c.islower() for c in password):
            return False, "Password must contain at least one lowercase letter"
        if not any(c.isdigit() for c in password):
            return False, "Password must contain at least one number"
        return True, ""

    # ── JWT Access Tokens ────────────────────────────────────

    def create_access_token(self, user_id: str, email: str, role: str) -> str:
        """Create a short-lived JWT access token."""
        expires = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_MINS)
        payload = {
            "sub": user_id,
            "email": email,
            "role": role,
            "type": "access",
            "exp": expires,
            "iat": datetime.now(timezone.utc),
            "jti": str(uuid.uuid4()),        # JWT ID — allows individual token revocation
        }
        return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

    def create_refresh_token(self) -> tuple[str, str]:
        """
        Create a refresh token.
        Returns (raw_token, hashed_token).
        raw_token is sent to the client, hashed_token is stored in DB.
        """
        raw = secrets.token_urlsafe(64)
        hashed = hashlib.sha256(raw.encode()).hexdigest()
        return raw, hashed

    def decode_access_token(self, token: str) -> Optional[dict]:
        """
        Decode and validate a JWT access token.
        Returns the payload dict or None if invalid/expired.
        """
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
            if payload.get("type") != "access":
                return None
            return payload
        except JWTError as e:
            logger.debug(f"Token decode failed: {e}")
            return None

    def hash_refresh_token(self, raw_token: str) -> str:
        """Hash a refresh token for database storage."""
        return hashlib.sha256(raw_token.encode()).hexdigest()

    # ── API Keys ─────────────────────────────────────────────

    def generate_api_key(self, org_prefix: str = "lv") -> tuple[str, str, str]:
        """
        Generate a B2B API key.
        Returns (raw_key, key_hash, key_prefix).

        Format: lv_prod_<32 random chars>
        e.g.  : lv_prod_x7k2mN9pQr4wYv8tUz3sLe6nCf1dAi5j
        """
        random_part = secrets.token_urlsafe(24)
        raw_key = f"{org_prefix}_api_{random_part}"
        key_prefix = raw_key[:8]
        key_hash = pwd_context.hash(raw_key)
        return raw_key, key_hash, key_prefix

    def verify_api_key(self, raw_key: str, stored_hash: str) -> bool:
        """Verify an API key against its stored bcrypt hash."""
        return pwd_context.verify(raw_key, stored_hash)

    # ── Email Verification ───────────────────────────────────

    def create_email_verification_token(self, user_id: str, email: str) -> str:
        """Create a short-lived email verification JWT (24 hours)."""
        expires = datetime.now(timezone.utc) + timedelta(hours=24)
        payload = {
            "sub": user_id,
            "email": email,
            "type": "email_verify",
            "exp": expires,
        }
        return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

    def decode_email_verification_token(self, token: str) -> Optional[dict]:
        """Decode an email verification token."""
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
            if payload.get("type") != "email_verify":
                return None
            return payload
        except JWTError:
            return None

    def create_password_reset_token(self, user_id: str) -> str:
        """Create a password reset token (1 hour expiry)."""
        expires = datetime.now(timezone.utc) + timedelta(hours=1)
        payload = {
            "sub": user_id,
            "type": "password_reset",
            "exp": expires,
            "jti": secrets.token_urlsafe(16),
        }
        return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

    def decode_password_reset_token(self, token: str) -> Optional[str]:
        """Decode a password reset token. Returns user_id or None."""
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
            if payload.get("type") != "password_reset":
                return None
            return payload.get("sub")
        except JWTError:
            return None


# Singleton
auth_service = AuthService()

REFRESH_TOKEN_DAYS = REFRESH_TOKEN_DAYS  # re-export
