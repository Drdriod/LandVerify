"""
LandVerify — SMS Service
Uses Termii (Nigerian SMS gateway) for OTP and fraud alerts.
Falls back to console log in dev.
"""
import logging, httpx

logger = logging.getLogger(__name__)

class SMSService:
    BASE_URL = "https://api.ng.termii.com/api/sms/send"

    def __init__(self):
        try:
            from app.config import get_settings
            s = get_settings()
            self.api_key   = getattr(s, 'termii_api_key', '')
            self.sender_id = getattr(s, 'termii_sender_id', 'LandVerify')
        except Exception:
            self.api_key = ''; self.sender_id = 'LandVerify'

    async def _send(self, phone: str, message: str) -> bool:
        if not self.api_key:
            logger.info(f"[SMS STUB] To: {phone} | {message}")
            return True
        async with httpx.AsyncClient() as client:
            r = await client.post(self.BASE_URL, json={
                "api_key": self.api_key, "to": phone,
                "from": self.sender_id, "sms": message, "type": "plain", "channel": "generic"
            })
            if r.status_code != 200:
                logger.error(f"Termii error {r.status_code}: {r.text}")
                return False
            return True

    async def send_otp(self, phone: str, otp: str):
        await self._send(phone, f"Your LandVerify OTP is: {otp}. Valid for 10 minutes. Do not share.")

    async def send_fraud_alert(self, phone: str, property_ref: str, severity: str):
        await self._send(phone,
            f"LandVerify ALERT: {severity.upper()} fraud risk on {property_ref}. Login to take action: app.landverify.ng")

    async def send_verification_done(self, phone: str, score: float, level: str):
        emoji = "✅" if level == "safe" else "⚠️" if level == "caution" else "🚫"
        await self._send(phone, f"{emoji} LandVerify: Verification complete. Trust Score: {score:.0f}/100 ({level.upper()}). View report at app.landverify.ng")

sms_service = SMSService()
