"""
LandVerify — Alerts & Dashboard Router
GET  /api/v1/dashboard
GET  /api/v1/alerts
POST /api/v1/alerts/subscribe
PATCH /api/v1/alerts/{id}/resolve
"""
import logging, uuid
from typing import Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.database import get_db
from app.models.orm import User, FraudAlert, AlertSubscription, Property, Verification
from app.routers.auth import get_current_user

router = APIRouter(prefix="/api/v1", tags=["Alerts & Dashboard"])
logger = logging.getLogger(__name__)


class SubscribeRequest(BaseModel):
    property_address: str
    file_number: Optional[str] = None
    notify_email: bool = True
    notify_sms: bool = False

class ResolveRequest(BaseModel):
    notes: str = ""


@router.get("/dashboard")
async def dashboard(current_user: User = Depends(get_current_user),
                    db: AsyncSession = Depends(get_db)):
    """Real dashboard stats from the database."""
    # Verification stats
    ver_count = await db.scalar(
        select(func.count(Verification.id)).where(Verification.user_id == current_user.id)
    )
    safe_count = await db.scalar(
        select(func.count(Verification.id)).where(
            Verification.user_id == current_user.id, Verification.trust_level == "safe"
        )
    )
    danger_count = await db.scalar(
        select(func.count(Verification.id)).where(
            Verification.user_id == current_user.id, Verification.trust_level == "danger"
        )
    )
    caution_count = await db.scalar(
        select(func.count(Verification.id)).where(
            Verification.user_id == current_user.id, Verification.trust_level == "caution"
        )
    )

    # Monitoring stats
    monitored = await db.scalar(
        select(func.count(AlertSubscription.id)).where(
            AlertSubscription.user_id == current_user.id,
            AlertSubscription.cancelled_at == None,
        )
    )
    active_alerts = await db.scalar(
        select(func.count(FraudAlert.id))
        .join(AlertSubscription, AlertSubscription.property_id == FraudAlert.property_id)
        .where(
            AlertSubscription.user_id == current_user.id,
            AlertSubscription.cancelled_at == None,
            FraudAlert.is_resolved == False,
        )
    )

    # Recent verifications
    recent_result = await db.execute(
        select(Verification)
        .where(Verification.user_id == current_user.id)
        .order_by(Verification.created_at.desc())
        .limit(5)
    )
    recent = recent_result.scalars().all()

    return {
        "user": {
            "id": str(current_user.id),
            "full_name": current_user.full_name,
            "plan": current_user.plan,
            "verifications_used": current_user.verifications_used,
            "verifications_limit": current_user.verifications_limit,
        },
        "stats": {
            "total": ver_count or 0,
            "safe": safe_count or 0,
            "caution": caution_count or 0,
            "danger": danger_count or 0,
            "monitored_properties": monitored or 0,
            "active_alerts": active_alerts or 0,
        },
        "recent_verifications": [
            {
                "id": str(v.id),
                "property_address": v.declared_address,
                "state": v.declared_state,
                "trust_score": float(v.trust_score) if v.trust_score else None,
                "trust_level": v.trust_level,
                "created_at": v.created_at.isoformat(),
            }
            for v in recent
        ],
    }


@router.get("/alerts")
async def list_alerts(
    unresolved_only: bool = False,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """List fraud alerts for properties the user monitors."""
    query = (
        select(FraudAlert)
        .join(AlertSubscription, AlertSubscription.property_id == FraudAlert.property_id)
        .where(
            AlertSubscription.user_id == current_user.id,
            AlertSubscription.cancelled_at == None,
        )
        .order_by(FraudAlert.created_at.desc())
        .limit(50)
    )
    if unresolved_only:
        query = query.where(FraudAlert.is_resolved == False)

    result = await db.execute(query)
    alerts = result.scalars().all()

    return {
        "alerts": [
            {
                "id": str(a.id),
                "property_id": str(a.property_id),
                "alert_type": a.alert_type,
                "severity": a.severity,
                "title": a.title,
                "description": a.description,
                "recommended_action": a.recommended_action,
                "is_resolved": a.is_resolved,
                "created_at": a.created_at.isoformat(),
            }
            for a in alerts
        ],
        "total": len(alerts),
    }


@router.post("/alerts/subscribe")
async def subscribe(
    body: SubscribeRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Subscribe to fraud alerts for a property."""
    # Find or create property
    prop_result = await db.execute(
        select(Property).where(
            Property.address.ilike(f"%{body.property_address[:30]}%")
        ).limit(1)
    )
    prop = prop_result.scalar_one_or_none()

    if not prop:
        prop = Property(
            address=body.property_address,
            state="lagos",
            is_monitored=True,
        )
        db.add(prop)
        await db.flush()
    else:
        prop.is_monitored = True

    # Check already subscribed
    existing = await db.scalar(
        select(func.count(AlertSubscription.id)).where(
            AlertSubscription.user_id == current_user.id,
            AlertSubscription.property_id == prop.id,
            AlertSubscription.cancelled_at == None,
        )
    )
    if existing:
        raise HTTPException(status_code=409, detail="Already monitoring this property")

    sub = AlertSubscription(
        user_id=current_user.id,
        property_id=prop.id,
        notify_email=body.notify_email,
        notify_sms=body.notify_sms,
    )
    db.add(sub)
    await db.flush()

    return {
        "message": "Monitoring enabled",
        "property_id": str(prop.id),
        "subscription_id": str(sub.id),
        "notify_email": sub.notify_email,
        "notify_sms": sub.notify_sms,
    }


@router.patch("/alerts/{alert_id}/resolve")
async def resolve_alert(
    alert_id: str,
    body: ResolveRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Mark a fraud alert as resolved."""
    result = await db.execute(select(FraudAlert).where(FraudAlert.id == alert_id))
    alert = result.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    alert.is_resolved = True
    alert.resolved_at = datetime.now(timezone.utc)
    alert.resolved_by = current_user.id
    alert.resolution_notes = body.notes

    return {"message": "Alert resolved", "alert_id": alert_id}
