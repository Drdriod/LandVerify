"""
LandVerify — Verification Router
The main API endpoint that orchestrates all verification services.

POST /api/v1/verify
  → OCR (text extraction)
  → Rule-based fraud checks
  → Claude AI analysis (authenticity + fraud + ownership)
  → Trust Score calculation
  → Final report generation
  → Response
"""
import uuid
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, UploadFile, File, Form, HTTPException, status
from fastapi.responses import JSONResponse

from app.models.document import (
    VerificationRequest, VerificationResult, VerificationCheck,
    DocumentType, NigerianState, UserRole, CheckStatus,
    TrustLevel, FraudFlag, FraudSeverity
)
from app.services.ocr_service import ocr_service
from app.services.claude_service import claude_service
from app.services.trust_score_service import trust_score_service
from app.services.fraud_service import fraud_detection_service
from app.services.ownership_service import ownership_service

router = APIRouter(prefix="/api/v1", tags=["Verification"])
logger = logging.getLogger(__name__)


@router.post("/verify", response_model=VerificationResult)
async def verify_document(
    document_type: DocumentType = Form(...),
    state: NigerianState = Form(...),
    property_address: str = Form(...),
    owner_name: str = Form(...),
    user_role: UserRole = Form(...),
    file_number: Optional[str] = Form(None),
    additional_notes: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
):
    """
    Main verification endpoint.

    Accepts a land document (optional) plus form data,
    runs the full verification pipeline, and returns a
    complete VerificationResult with Trust Score, checks,
    fraud flags, and ownership chain.
    """
    verification_id = str(uuid.uuid4())
    logger.info(f"Starting verification {verification_id} for {property_address}")

    try:
        # ─── STEP 1: OCR — Extract text from uploaded document ───
        extracted_text = None
        if file and file.filename:
            logger.info(f"Extracting text from document: {file.filename}")
            file_bytes = await file.read()
            try:
                extracted_text = await ocr_service.extract_text_from_file(
                    file_bytes, file.filename
                )
            except Exception as e:
                logger.warning(f"OCR failed: {e} — continuing without document text")
                extracted_text = ocr_service._mock_document_text()
        else:
            # Use mock text if no file uploaded (for testing)
            extracted_text = ocr_service._mock_document_text()

        # Build request object
        request = VerificationRequest(
            document_type=document_type,
            state=state,
            property_address=property_address,
            owner_name=owner_name,
            file_number=file_number,
            user_role=user_role,
            additional_notes=additional_notes,
            extracted_text=extracted_text,
        )

        # ─── STEP 2: Parse document metadata ───
        logger.info("Parsing document metadata")
        metadata = ocr_service.parse_metadata(extracted_text, state)
        if file_number:
            metadata.file_number = file_number  # Override with user-provided
        metadata.owner_name = owner_name

        # ─── STEP 3: Rule-based fraud detection ───
        logger.info("Running rule-based fraud checks")
        rule_fraud_flags = fraud_detection_service.run_all_checks(
            metadata, request, additional_notes
        )

        # ─── STEP 4: Claude AI analysis (authenticity + fraud + ownership) ───
        logger.info("Running Claude AI document analysis")
        try:
            authenticity_data = await claude_service.analyse_document_authenticity(
                metadata, request
            )
            ai_fraud_data = await claude_service.detect_fraud_patterns(
                metadata, request
            )
            ownership_data = await claude_service.reconstruct_ownership_chain(
                metadata, request
            )
        except Exception as e:
            logger.error(f"Claude API call failed: {e}")
            # Fallback to mock data for development
            authenticity_data = _mock_authenticity_data()
            ai_fraud_data = _mock_fraud_data()
            ownership_data = _mock_ownership_data(owner_name)

        # ─── STEP 5: Build verification checks list ───
        checks = _build_checks_from_authenticity(authenticity_data)

        checks_passed = sum(1 for c in checks if c.status == CheckStatus.PASS)
        checks_failed = sum(1 for c in checks if c.status == CheckStatus.FAIL)
        checks_warned = sum(1 for c in checks if c.status == CheckStatus.WARNING)

        # ─── STEP 6: Combine fraud flags (rule-based + AI) ───
        ai_fraud_flags = _parse_ai_fraud_flags(ai_fraud_data.get("flags", []))
        all_fraud_flags = rule_fraud_flags + ai_fraud_flags

        # ─── STEP 7: Build ownership chain ───
        property_id = str(uuid.uuid4())
        chain = ownership_service.build_from_claude_response(ownership_data, property_id)
        chain_integrity = ownership_service.calculate_chain_integrity_score(chain)

        # ─── STEP 8: Calculate Trust Score ───
        authenticity_score = float(authenticity_data.get("authenticity_score", 0.6))
        registry_score = trust_score_service.mock_registry_score(
            metadata.file_number, state.value
        )
        encumbrance_score = trust_score_service.mock_encumbrance_score(extracted_text)
        geospatial_score = trust_score_service.mock_geospatial_score(
            metadata.coordinates, state.value
        )

        score_breakdown = trust_score_service.calculate(
            authenticity_score=authenticity_score,
            registry_match_score=registry_score,
            ownership_chain_integrity=chain_integrity,
            encumbrance_score=encumbrance_score,
            geospatial_score=geospatial_score,
            fraud_flags=all_fraud_flags,
        )

        # ─── STEP 9: Generate final report ───
        try:
            report = await claude_service.generate_verification_report(
                trust_score=score_breakdown.final_score,
                trust_level=score_breakdown.trust_level.value,
                checks_summary={
                    "passed": checks_passed,
                    "failed": checks_failed,
                    "warned": checks_warned,
                },
                fraud_summary={
                    "fraud_risk_level": ai_fraud_data.get("fraud_risk_level", "unknown"),
                    "flag_count": len(all_fraud_flags),
                },
                ownership_summary={
                    "chain_integrity": chain_integrity,
                    "has_gaps": chain.has_gaps,
                },
                user_role=user_role.value,
                property_address=property_address,
            )
        except Exception as e:
            logger.error(f"Report generation failed: {e}")
            report = _mock_report(score_breakdown.trust_level, user_role.value)

        # ─── STEP 10: Assemble final result ───
        result = VerificationResult(
            verification_id=verification_id,
            timestamp=datetime.utcnow(),
            property_address=property_address,
            document_type=document_type,
            state=state,
            trust_score=score_breakdown.final_score,
            trust_level=score_breakdown.trust_level,
            trust_score_breakdown=score_breakdown,
            checks=checks,
            checks_passed=checks_passed,
            checks_failed=checks_failed,
            checks_warned=checks_warned,
            fraud_flags=all_fraud_flags,
            fraud_risk_summary=ai_fraud_data.get(
                "fraud_summary",
                "Fraud analysis completed."
            ),
            ownership_chain=chain,
            ai_summary=report.get("executive_summary", "Verification completed."),
            ai_recommendation=report.get("role_specific_recommendation", "Proceed with caution."),
        )

        logger.info(
            f"Verification {verification_id} complete — "
            f"Trust Score: {score_breakdown.final_score} ({score_breakdown.trust_level.value})"
        )

        return result

    except Exception as e:
        logger.error(f"Verification {verification_id} failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Verification failed: {str(e)}"
        )


@router.post("/verify/ocr-only")
async def extract_text_only(file: UploadFile = File(...)):
    """
    Extract text from a document without running full verification.
    Useful for testing OCR quality before full submission.
    """
    try:
        file_bytes = await file.read()
        text = await ocr_service.extract_text_from_file(file_bytes, file.filename)
        return {"filename": file.filename, "extracted_text": text, "char_count": len(text)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# ─────────────────────────────────────────────
# HELPER FUNCTIONS
# ─────────────────────────────────────────────

def _build_checks_from_authenticity(authenticity_data: dict) -> list:
    """Convert Claude's authenticity check data to VerificationCheck objects."""
    checks = []
    for c in authenticity_data.get("checks", []):
        status_map = {
            "pass": CheckStatus.PASS,
            "fail": CheckStatus.FAIL,
            "warning": CheckStatus.WARNING,
        }
        checks.append(VerificationCheck(
            check_id=c.get("check_id", str(uuid.uuid4())),
            label=c.get("label", "Unknown Check"),
            status=status_map.get(c.get("status", "warning"), CheckStatus.WARNING),
            detail=c.get("detail", ""),
            weight=float(c.get("weight", 0.1)),
        ))
    return checks


def _parse_ai_fraud_flags(flags_data: list) -> list:
    """Parse Claude's fraud flag data into FraudFlag objects."""
    flags = []
    severity_map = {
        "low": FraudSeverity.LOW,
        "medium": FraudSeverity.MEDIUM,
        "high": FraudSeverity.HIGH,
        "critical": FraudSeverity.CRITICAL,
    }
    for f in flags_data:
        flags.append(FraudFlag(
            flag_id=f.get("flag_id", str(uuid.uuid4())),
            severity=severity_map.get(f.get("severity", "medium"), FraudSeverity.MEDIUM),
            title=f.get("title", "Fraud Indicator"),
            description=f.get("description", ""),
            recommendation=f.get("recommendation", "Consult a property lawyer."),
            confidence=float(f.get("confidence", 0.7)),
        ))
    return flags


# ─────────────────────────────────────────────
# MOCK FALLBACK DATA (for development without Claude API)
# ─────────────────────────────────────────────

def _mock_authenticity_data() -> dict:
    return {
        "authenticity_score": 0.74,
        "checks": [
            {"check_id": "format_validity", "label": "Document Format Valid", "status": "pass", "detail": "Matches standard Lagos State C of O template", "weight": 0.20},
            {"check_id": "stamp_duty", "label": "Stamp Duty Verified", "status": "pass", "detail": "FIRS stamp reference found in document", "weight": 0.15},
            {"check_id": "governor_signature", "label": "Governor Signature Period", "status": "pass", "detail": "Governor name matches the declared issuance period", "weight": 0.15},
            {"check_id": "document_consistency", "label": "Internal Consistency", "status": "warning", "detail": "Minor date inconsistency between header and body", "weight": 0.20},
            {"check_id": "file_number_format", "label": "File Number Format", "status": "fail", "detail": "File number not confirmed in registry database", "weight": 0.10},
            {"check_id": "survey_plan_present", "label": "Survey Plan Referenced", "status": "pass", "detail": "Survey plan number found in document", "weight": 0.10},
            {"check_id": "address_consistency", "label": "Address Consistency", "status": "pass", "detail": "Address matches declared property location", "weight": 0.10},
        ],
        "anomalies_detected": ["File number not confirmed in live registry"],
        "authenticity_summary": "Document appears largely authentic with one unconfirmed file number."
    }

def _mock_fraud_data() -> dict:
    return {
        "fraud_risk_level": "medium",
        "overall_fraud_score": 0.28,
        "flags": [
            {
                "flag_id": "registry_match_fail",
                "severity": "high",
                "title": "Registry Confirmation Pending",
                "description": "The file number could not be confirmed against the live Lagos State Land Registry. This may indicate a recently issued document not yet in our database, or a potentially fraudulent document.",
                "recommendation": "Visit the Lagos State Land Registry at Alausa, Ikeja in person to verify this file number before making any payment.",
                "confidence": 0.75
            }
        ],
        "fraud_summary": "This document presents medium fraud risk primarily due to an unconfirmed registry file number. All other indicators appear normal. Physical registry verification is strongly recommended before proceeding.",
        "safe_to_proceed": False,
        "immediate_actions": ["Verify file number at Lagos State Land Registry", "Request seller to provide Governor's Consent"]
    }

def _mock_ownership_data(owner_name: str) -> dict:
    return {
        "chain_integrity": 0.82,
        "has_gaps": False,
        "has_disputes": False,
        "total_owners": 4,
        "records": [
            {"year": "1987", "owner_name": "Lagos State Government", "transaction_type": "Original Allocation", "consideration": "N/A", "instrument": "Government Notice", "registered": True, "flagged": False, "flag_reason": None},
            {"year": "1995", "owner_name": "Chief Adewale Fashola", "transaction_type": "Purchase", "consideration": "₦180,000", "instrument": "Deed of Assignment", "registered": True, "flagged": False, "flag_reason": None},
            {"year": "2008", "owner_name": "Fashola Family Trust", "transaction_type": "Inheritance", "consideration": "N/A — Probate", "instrument": "Letters of Administration", "registered": True, "flagged": False, "flag_reason": None},
            {"year": "2021", "owner_name": owner_name, "transaction_type": "Purchase", "consideration": "₦45,000,000", "instrument": "Deed of Assignment — Registered", "registered": True, "flagged": False, "flag_reason": None},
        ],
        "chain_gaps": [],
        "analysis_summary": "The ownership chain is well-documented across 4 transfers since 1987. All transfers are registered. No disputes detected."
    }

def _mock_report(trust_level: TrustLevel, user_role: str) -> dict:
    if trust_level == TrustLevel.SAFE:
        summary = "This property has passed most verification checks and presents a relatively low risk profile. Standard legal due diligence is still recommended before any final payment."
        recommendation = "As a buyer, you may proceed to the next stage — engage a qualified property lawyer to conduct a final physical search at the Land Registry and review all original documents."
    elif trust_level == TrustLevel.CAUTION:
        summary = "This property presents moderate risk with some anomalies that require further investigation. Do not make any payment until these concerns are resolved."
        recommendation = "Do not pay any money at this stage. Engage a property lawyer immediately to investigate the flagged issues, particularly the unconfirmed file number."
    else:
        summary = "This property presents HIGH fraud risk. Multiple serious red flags have been detected. Proceeding with this transaction as-is would put your money at significant risk."
        recommendation = "Stop all negotiations immediately. Do not make any payment. Report this to the EFCC if you suspect fraud. Consult a property lawyer before taking any further action."

    return {
        "executive_summary": summary,
        "role_specific_recommendation": recommendation,
        "key_risks": ["Unconfirmed registry file number", "Ownership chain gap possible"],
        "next_steps": ["Engage a property lawyer", "Visit Land Registry physically", "Request original documents"],
        "professional_referral": "Nigerian Bar Association — Property Law Section"
    }
