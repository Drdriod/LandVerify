"""
LandVerify — Auth Router
POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/logout
POST /api/v1/auth/refresh
GET  /api/v1/auth/me
GET  /api/v1/auth/verify-email/{token}
POST /api/v1/auth/forgot-password
POST /api/v1/auth/reset-password
"""
import uuid, hashlib, logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, Column, String, DateTime, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from app.database import get_db, Base
from app.models.orm import User
from app.services.auth_service import auth_service
from app.middleware.security import brute_force

router = APIRouter(prefix="/api/v1/auth", tags=["Authentication"])
logger = logging.getLogger(__name__)
security = HTTPBearer(auto_error=False)

REFRESH_DAYS = 30


# ── Refresh token table ────────────────────────────────────────────
class RefreshToken(Base):
    __tablename__ = "refresh_tokens"
    id         = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id    = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    token_hash = Column(String(64), unique=True, nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    revoked    = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


# ── Schemas ────────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    full_name: str = Field(..., min_length=2, max_length=100)
    phone: Optional[str] = None
    role: str = "buyer"

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class RefreshRequest(BaseModel):
    refresh_token: str

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8)


# ── Shared dep ─────────────────────────────────────────────────────
async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    if not credentials:
        raise HTTPException(status_code=401, detail="Authentication required",
                            headers={"WWW-Authenticate": "Bearer"})
    payload = auth_service.decode_access_token(credentials.credentials)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token",
                            headers={"WWW-Authenticate": "Bearer"})
    result = await db.execute(
        select(User).where(User.id == payload["sub"], User.deleted_at == None)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=401, detail="Account not found")
    return user

async def get_current_user_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    if not credentials:
        return None
    try:
        return await get_current_user(credentials, db)
    except HTTPException:
        return None


# ── Register ───────────────────────────────────────────────────────
@router.post("/register", status_code=201)
async def register(body: RegisterRequest, request: Request, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(select(User).where(User.email == body.email.lower()))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="An account with this email already exists")

    valid, msg = auth_service.validate_password_strength(body.password)
    if not valid:
        raise HTTPException(status_code=422, detail=msg)

    valid_roles = {"buyer", "lawyer", "bank", "developer", "seller"}
    if body.role not in valid_roles:
        raise HTTPException(status_code=422, detail=f"Role must be one of: {', '.join(valid_roles)}")

    user = User(
        email=body.email.lower().strip(),
        full_name=body.full_name.strip(),
        phone=body.phone,
        role=body.role,
        password_hash=auth_service.hash_password(body.password),
        verifications_limit=3,
    )
    db.add(user)
    await db.flush()

    access = auth_service.create_access_token(str(user.id), user.email, user.role)
    raw, hashed = auth_service.create_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=hashed,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=REFRESH_DAYS)))

    logger.info(f"Registered: {user.email} [{user.role}]")
    return {"access_token": access, "refresh_token": raw, "token_type": "bearer",
            "expires_in": 1800, "user": _user_dict(user)}


# ── Login ──────────────────────────────────────────────────────────
@router.post("/login")
async def login(body: LoginRequest, request: Request, db: AsyncSession = Depends(get_db)):
    ip = request.client.host if request.client else "unknown"

    locked, secs = brute_force.is_locked(ip, body.email.lower())
    if locked:
        raise HTTPException(status_code=429,
                            detail=f"Too many attempts. Try again in {secs} seconds.")

    result = await db.execute(
        select(User).where(User.email == body.email.lower(), User.deleted_at == None)
    )
    user = result.scalar_one_or_none()

    if not user or not auth_service.verify_password(body.password, user.password_hash):
        brute_force.record_failure(ip, body.email.lower())
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    brute_force.record_success(ip, body.email.lower())
    user.last_active_at = datetime.now(timezone.utc)

    access = auth_service.create_access_token(str(user.id), user.email, user.role)
    raw, hashed = auth_service.create_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=hashed,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=REFRESH_DAYS)))

    logger.info(f"Login: {user.email}")
    return {"access_token": access, "refresh_token": raw, "token_type": "bearer",
            "expires_in": 1800, "user": _user_dict(user)}


# ── Refresh ────────────────────────────────────────────────────────
@router.post("/refresh")
async def refresh(body: RefreshRequest, db: AsyncSession = Depends(get_db)):
    h = hashlib.sha256(body.refresh_token.encode()).hexdigest()
    result = await db.execute(
        select(RefreshToken).where(
            RefreshToken.token_hash == h, RefreshToken.revoked == False,
            RefreshToken.expires_at > datetime.now(timezone.utc),
        )
    )
    stored = result.scalar_one_or_none()
    if not stored:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

    stored.revoked = True  # Rotate
    user_r = await db.execute(select(User).where(User.id == stored.user_id, User.deleted_at == None))
    user = user_r.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=401, detail="Account not found")

    new_access = auth_service.create_access_token(str(user.id), user.email, user.role)
    raw, hashed = auth_service.create_refresh_token()
    db.add(RefreshToken(user_id=user.id, token_hash=hashed,
                        expires_at=datetime.now(timezone.utc) + timedelta(days=REFRESH_DAYS)))

    return {"access_token": new_access, "refresh_token": raw, "token_type": "bearer",
            "expires_in": 1800, "user": _user_dict(user)}


# ── Logout ─────────────────────────────────────────────────────────
@router.post("/logout")
async def logout(body: RefreshRequest, db: AsyncSession = Depends(get_db),
                 current_user: User = Depends(get_current_user)):
    h = hashlib.sha256(body.refresh_token.encode()).hexdigest()
    result = await db.execute(
        select(RefreshToken).where(RefreshToken.token_hash == h,
                                   RefreshToken.user_id == current_user.id)
    )
    stored = result.scalar_one_or_none()
    if stored:
        stored.revoked = True
    return {"message": "Logged out successfully"}


# ── Me ─────────────────────────────────────────────────────────────
@router.get("/me")
async def me(current_user: User = Depends(get_current_user)):
    return _user_dict(current_user)


# ── Verify email ───────────────────────────────────────────────────
@router.get("/verify-email/{token}")
async def verify_email(token: str, db: AsyncSession = Depends(get_db)):
    payload = auth_service.decode_email_verification_token(token)
    if not payload:
        raise HTTPException(status_code=400, detail="Invalid or expired verification link")
    result = await db.execute(select(User).where(User.id == payload["sub"]))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.email_verified:
        return {"message": "Email already verified"}
    user.email_verified = True
    user.kyc_completed_at = datetime.now(timezone.utc)
    return {"message": "Email verified successfully"}


# ── Forgot password ────────────────────────────────────────────────
@router.post("/forgot-password")
async def forgot_password(body: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.email == body.email.lower()))
    user = result.scalar_one_or_none()
    if user:
        token = auth_service.create_password_reset_token(str(user.id))
        logger.info(f"[DEV] Password reset token for {user.email}: {token[:30]}...")
        # Production: await email_service.send_password_reset(user.email, token)
    return {"message": "If that account exists, a reset link has been sent to your email"}


# ── Reset password ─────────────────────────────────────────────────
@router.post("/reset-password")
async def reset_password(body: ResetPasswordRequest, db: AsyncSession = Depends(get_db)):
    user_id = auth_service.decode_password_reset_token(body.token)
    if not user_id:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    valid, msg = auth_service.validate_password_strength(body.new_password)
    if not valid:
        raise HTTPException(status_code=422, detail=msg)
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.password_hash = auth_service.hash_password(body.new_password)
    return {"message": "Password reset successfully. You can now log in."}


# ── Helper ─────────────────────────────────────────────────────────
def _user_dict(user: User) -> dict:
    return {
        "id": str(user.id),
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "plan": user.plan,
        "email_verified": user.email_verified,
        "verifications_used": user.verifications_used,
        "verifications_limit": user.verifications_limit,
        "can_verify": user.can_verify(),
    }
