"""
LandVerify — Security Middleware
Brute force protection, input sanitization, file validation.
"""
import re, time, logging, os
from collections import defaultdict

logger = logging.getLogger(__name__)

class BruteForceProtection:
    MAX_ATTEMPTS = 5
    LOCKOUT_SECONDS = 900
    def __init__(self):
        self._attempts = defaultdict(list)
        self._locked = {}
    def record_failure(self, ip, email):
        now = time.time()
        for key in [f"ip:{ip}", f"email:{email}"]:
            self._attempts[key] = [t for t in self._attempts[key] if now - t < self.LOCKOUT_SECONDS]
            self._attempts[key].append(now)
            if len(self._attempts[key]) >= self.MAX_ATTEMPTS:
                self._locked[key] = now + self.LOCKOUT_SECONDS
                logger.warning(f"Brute force lockout: {key}")
    def record_success(self, ip, email):
        for key in [f"ip:{ip}", f"email:{email}"]:
            self._attempts.pop(key, None); self._locked.pop(key, None)
    def is_locked(self, ip, email):
        now = time.time()
        for key in [f"ip:{ip}", f"email:{email}"]:
            unlock_at = self._locked.get(key)
            if unlock_at and now < unlock_at: return True, int(unlock_at - now)
            elif unlock_at: del self._locked[key]
        return False, 0

brute_force = BruteForceProtection()

class InputSanitizer:
    PATTERNS = [
        r"ignore\s+(previous|all|above|prior)\s+instructions?",
        r"disregard\s+(previous|all|above|prior)\s+instructions?",
        r"forget\s+(everything|all|your|the)\s+(previous|prior|above)",
        r"you\s+are\s+now\s+a", r"pretend\s+(you\s+are|to\s+be)",
        r"act\s+as\s+(if\s+you\s+are|a)", r"<\s*script", r"javascript:", r"\[SYSTEM\]",
    ]
    def __init__(self):
        self._pats = [re.compile(p, re.IGNORECASE) for p in self.PATTERNS]
    def sanitize(self, text, field='input', max_length=2000):
        if not text: return ''
        text = text.replace('\x00', '')
        if len(text) > max_length: text = text[:max_length]
        for p in self._pats:
            if p.search(text):
                logger.warning(f"Prompt injection attempt in '{field}'")
                text = p.sub('[REMOVED]', text)
        return re.sub(r'\s+', ' ', text).strip()
    def sanitize_dict(self, data, max_lengths=None):
        ml = max_lengths or {}
        return {k: self.sanitize(v, k, ml.get(k, 2000)) if isinstance(v, str) else v
                for k, v in data.items()}

sanitizer = InputSanitizer()

ALLOWED_MIME = {'application/pdf','image/jpeg','image/png','image/tiff','image/webp'}
ALLOWED_EXT  = {'.pdf','.jpg','.jpeg','.png','.tiff','.tif','.webp'}
MAX_BYTES    = 10 * 1024 * 1024
MAGIC = {
    b'\x25\x50\x44\x46': ('application/pdf', {'.pdf'}),
    b'\xff\xd8\xff':      ('image/jpeg', {'.jpg','.jpeg'}),
    b'\x89\x50\x4e\x47': ('image/png', {'.png'}),
    b'\x49\x49\x2a\x00': ('image/tiff', {'.tiff','.tif'}),
    b'\x4d\x4d\x00\x2a': ('image/tiff', {'.tiff','.tif'}),
}

def validate_upload(filename, content_type, file_bytes):
    ext = os.path.splitext(filename.lower())[1]
    if ext not in ALLOWED_EXT:
        return False, f"Extension '{ext}' not allowed. Use PDF, JPG, or PNG."
    if content_type and content_type not in ALLOWED_MIME:
        return False, f"Content type '{content_type}' not accepted."
    if len(file_bytes) > MAX_BYTES:
        return False, f"File too large ({len(file_bytes)/1024/1024:.1f} MB). Max 10 MB."
    for sig, (mime, exts) in MAGIC.items():
        if file_bytes[:len(sig)] == sig:
            if ext not in exts:
                return False, f"File is {mime} but extension is '{ext}'."
            return True, ''
    return True, ''
