# LandVerify — Local Test Setup

Nigeria's Land Trust Layer. AI-powered land document verification.

---

## What you need
- Python 3.10+
- An Anthropic API key → [console.anthropic.com](https://console.anthropic.com)
- PostgreSQL (optional — verification still works without it)

---

## Step 1 — Install dependencies

```bash
cd landverify-backend
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

---

## Step 2 — Set your API key

Edit `.env` and replace `your-api-key-here`:

```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Everything else in `.env` works as-is.

---

## Step 3 — (Optional) Set up PostgreSQL

If you have PostgreSQL installed:

```bash
psql postgres -c "CREATE USER landverify WITH PASSWORD 'landverify';"
psql postgres -c "CREATE DATABASE landverify OWNER landverify;"
```

If you skip this, verification still works — it just won't save history.

---

## Step 4 — Start the backend

```bash
source venv/bin/activate
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

You should see:
```
═══════════════════════════════════════════════════════
  LandVerify API  —  Starting Up
  Version : 1.0.0
  Model   : claude-opus-4-6
  Docs    : http://localhost:8000/docs
═══════════════════════════════════════════════════════
```

---

## Step 5 — Open the frontend

Open **`landverify.html`** in your browser (just double-click it, or `open landverify.html`).

---

## Step 6 — Connect and test

### Option A: Demo mode (no backend needed)
1. Click **Verify**
2. Click **Try Demo Data**
3. Click **Run Verification**
4. See full results with Trust Score, fraud flags, ownership chain

### Option B: Live API (with backend running)
1. Click **LIVE API** chip
2. Click **Test ↗** — should show "✅ Connected"
3. Fill in property details
4. Click **Run Verification** — calls your local backend + Claude AI

---

## API Explorer

While backend is running, open: **http://localhost:8000/docs**

Interactive Swagger UI for all 12 endpoints.

---

## Key endpoints

| Method | Path | What it does |
|--------|------|--------------|
| POST | `/api/v1/verify` | Full verification (OCR + Claude AI + Trust Score) |
| POST | `/api/v1/auth/register` | Create account |
| POST | `/api/v1/auth/login` | Sign in, get JWT |
| GET  | `/api/v1/auth/me` | Current user + quota |
| GET  | `/api/v1/dashboard` | Stats + history |
| GET  | `/api/v1/alerts` | Fraud alerts |
| POST | `/api/v1/alerts/subscribe` | Monitor a property |
| GET  | `/health` | System health |

---

## Quick API test (curl)

```bash
# Health check
curl http://localhost:8000/health

# Register
curl -X POST http://localhost:8000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@landverify.ng","password":"Test1234!","full_name":"Emeka Obi","role":"buyer"}'

# Verify a property (no file — uses mock OCR)
curl -X POST http://localhost:8000/api/v1/verify \
  -F "document_type=certificate_of_occupancy" \
  -F "state=lagos" \
  -F "property_address=14B Admiralty Way, Lekki Phase 1" \
  -F "owner_name=Chukwuemeka Obi" \
  -F "user_role=buyer"
```

---

## Architecture

```
landverify.html          ← Frontend (open in browser)
landverify-backend/
  app/
    main.py              ← FastAPI app, CORS, error handling
    config.py            ← Settings from .env
    database.py          ← PostgreSQL connection (async SQLAlchemy)
    models/
      document.py        ← Pydantic schemas (API in/out)
      orm.py             ← SQLAlchemy ORM (13 tables)
    routers/
      verification.py    ← POST /verify — the core pipeline
      auth.py            ← Register, login, JWT, refresh tokens
      alerts.py          ← Dashboard, alerts, monitoring
    services/
      claude_service.py  ← Claude AI integration (authenticity, fraud, ownership)
      ocr_service.py     ← Tesseract OCR (falls back to mock)
      fraud_service.py   ← Rule-based fraud detection
      trust_score_service.py ← Weighted Trust Score algorithm
      ownership_service.py   ← Ownership chain reconstruction
      auth_service.py    ← JWT + bcrypt
    middleware/
      security.py        ← Brute force, input sanitizer, file validator
  schema.sql             ← Full PostgreSQL schema (13 tables, indexes, triggers)
  requirements.txt
  .env                   ← Your config (add API key here)
```

---

## Troubleshooting

**`ModuleNotFoundError: No module named 'fastapi'`**
→ You're not in the venv. Run `source venv/bin/activate` first.

**`anthropic.APIStatusError: 401`**
→ Your API key is wrong or not set. Check `.env`.

**`Connection refused` from frontend**
→ Backend isn't running. Run `uvicorn app.main:app --reload`.

**`asyncpg.exceptions.ConnectionDoesNotExistError`**
→ PostgreSQL isn't running. Either start it, or set `DATABASE_URL=` empty in `.env` — verification still works without DB.

---

## What works without PostgreSQL

✅ Full document verification (OCR + Claude AI + Trust Score + Fraud detection)  
✅ All endpoints return real results  
❌ Verification history not saved  
❌ Dashboard shows empty state  
❌ Alerts/monitoring not persisted  

---

Built by LandVerify — eliminating property fraud in Nigeria, one document at a time.
