-- ══════════════════════════════════════════════════════════════════
-- LANDVERIFY — POSTGRESQL DATABASE SCHEMA
-- Nigeria's Land Trust Layer
-- Version: 1.0.0
-- ══════════════════════════════════════════════════════════════════
--
-- Tables:
--   1. users               → All user accounts (buyers, lawyers, banks, devs)
--   2. organizations       → Companies, law firms, banks using the platform
--   3. properties          → Property records being tracked
--   4. documents           → Uploaded land documents
--   5. verifications       → Verification session results
--   6. verification_checks → Individual check results per verification
--   7. trust_scores        → Trust Score history per property
--   8. fraud_flags         → Detected fraud indicators
--   9. ownership_records   → Ownership chain entries per property
--  10. fraud_alerts        → Real-time fraud alert events
--  11. alert_subscriptions → Which users monitor which properties
--  12. registry_cache      → Cached state registry lookup results
--  13. audit_log           → Full audit trail of all actions
--  14. api_keys            → API keys for B2B integrations
-- ══════════════════════════════════════════════════════════════════

-- EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";    -- for fuzzy text search on names/addresses
CREATE EXTENSION IF NOT EXISTS "btree_gin";  -- for composite GIN indexes
CREATE EXTENSION IF NOT EXISTS "postgis";    -- for geospatial land boundary queries

-- ══════════════════════════════════════════════════════════════════
-- ENUMS
-- ══════════════════════════════════════════════════════════════════

CREATE TYPE user_role AS ENUM (
    'buyer',
    'lawyer',
    'bank',
    'developer',
    'seller',
    'admin'
);

CREATE TYPE document_type AS ENUM (
    'certificate_of_occupancy',
    'deed_of_assignment',
    'survey_plan',
    'governors_consent',
    'right_of_occupancy',
    'excision',
    'deed_of_gift',
    'probate',
    'court_order',
    'power_of_attorney'
);

CREATE TYPE nigerian_state AS ENUM (
    'abia', 'adamawa', 'akwa_ibom', 'anambra', 'bauchi', 'bayelsa',
    'benue', 'borno', 'cross_river', 'delta', 'ebonyi', 'edo',
    'ekiti', 'enugu', 'abuja_fct', 'gombe', 'imo', 'jigawa',
    'kaduna', 'kano', 'katsina', 'kebbi', 'kogi', 'kwara',
    'lagos', 'nasarawa', 'niger', 'ogun', 'ondo', 'osun',
    'oyo', 'plateau', 'rivers', 'sokoto', 'taraba', 'yobe', 'zamfara'
);

CREATE TYPE trust_level AS ENUM ('safe', 'caution', 'danger');

CREATE TYPE check_status AS ENUM ('pass', 'fail', 'warning', 'pending');

CREATE TYPE fraud_severity AS ENUM ('low', 'medium', 'high', 'critical');

CREATE TYPE alert_type AS ENUM (
    'duplicate_title',
    'unregistered_transfer',
    'suspicious_agent',
    'registry_mismatch',
    'encumbrance_added',
    'ownership_dispute',
    'court_order_filed',
    'mortgage_default'
);

CREATE TYPE verification_status AS ENUM ('pending', 'processing', 'complete', 'failed');

CREATE TYPE subscription_plan AS ENUM ('free', 'individual', 'professional', 'enterprise');

-- ══════════════════════════════════════════════════════════════════
-- 1. USERS
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email               VARCHAR(255) UNIQUE NOT NULL,
    phone               VARCHAR(20),
    full_name           VARCHAR(255) NOT NULL,
    password_hash       TEXT NOT NULL,
    role                user_role NOT NULL DEFAULT 'buyer',
    plan                subscription_plan NOT NULL DEFAULT 'free',

    -- Profile
    nin                 VARCHAR(11),                  -- National ID Number
    bvn                 VARCHAR(11),                  -- Bank Verification Number
    cac_number          VARCHAR(20),                  -- For businesses
    profession          VARCHAR(100),                 -- e.g. "Senior Property Lawyer"
    organization_id     UUID,                         -- FK to organizations

    -- Verification status
    email_verified      BOOLEAN NOT NULL DEFAULT FALSE,
    phone_verified      BOOLEAN NOT NULL DEFAULT FALSE,
    identity_verified   BOOLEAN NOT NULL DEFAULT FALSE,
    kyc_completed_at    TIMESTAMPTZ,

    -- Usage tracking
    verifications_used  INTEGER NOT NULL DEFAULT 0,
    verifications_limit INTEGER NOT NULL DEFAULT 3,   -- free plan limit
    last_active_at      TIMESTAMPTZ,

    -- Billing
    stripe_customer_id  VARCHAR(100),

    -- Metadata
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at          TIMESTAMPTZ
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_organization ON users(organization_id);
CREATE INDEX idx_users_plan ON users(plan);

-- ══════════════════════════════════════════════════════════════════
-- 2. ORGANIZATIONS
-- Represents law firms, banks, developer companies using LandVerify B2B
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE organizations (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name            VARCHAR(255) NOT NULL,
    cac_number      VARCHAR(20) UNIQUE,
    email           VARCHAR(255) NOT NULL,
    phone           VARCHAR(20),
    address         TEXT,
    state           nigerian_state,
    type            VARCHAR(50),            -- 'law_firm' | 'bank' | 'developer' | 'agency'
    plan            subscription_plan NOT NULL DEFAULT 'professional',

    -- API access
    api_calls_used  INTEGER NOT NULL DEFAULT 0,
    api_calls_limit INTEGER NOT NULL DEFAULT 1000,

    -- Verification
    verified        BOOLEAN NOT NULL DEFAULT FALSE,
    verified_at     TIMESTAMPTZ,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE users ADD CONSTRAINT fk_users_org
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE SET NULL;

-- ══════════════════════════════════════════════════════════════════
-- 3. PROPERTIES
-- Master record for every property tracked in LandVerify
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE properties (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),

    -- Identity
    address             TEXT NOT NULL,
    state               nigerian_state NOT NULL,
    lga                 VARCHAR(100),                     -- Local Government Area
    plot_number         VARCHAR(50),
    file_number         VARCHAR(50),                      -- Registry file number
    survey_plan_number  VARCHAR(50),

    -- Geospatial (PostGIS)
    location            GEOGRAPHY(POINT, 4326),           -- GPS coordinates
    boundary            GEOGRAPHY(POLYGON, 4326),         -- Plot boundary polygon
    land_size_sqm       DECIMAL(12, 4),

    -- Title info
    document_type       document_type,
    title_holder        VARCHAR(255),                     -- Current registered owner

    -- Trust Score (latest snapshot — full history in trust_scores table)
    current_trust_score DECIMAL(5, 2),
    current_trust_level trust_level,
    last_verified_at    TIMESTAMPTZ,

    -- Flags
    is_monitored        BOOLEAN NOT NULL DEFAULT FALSE,
    has_active_alert    BOOLEAN NOT NULL DEFAULT FALSE,
    is_disputed         BOOLEAN NOT NULL DEFAULT FALSE,
    is_government_acquired BOOLEAN NOT NULL DEFAULT FALSE,

    -- Audit
    created_by          UUID REFERENCES users(id),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Full-text search on address
CREATE INDEX idx_properties_address_fts ON properties USING gin(to_tsvector('english', address));
-- Trigram search for fuzzy address matching
CREATE INDEX idx_properties_address_trgm ON properties USING gin(address gin_trgm_ops);
-- State filtering
CREATE INDEX idx_properties_state ON properties(state);
-- File number lookup
CREATE INDEX idx_properties_file_number ON properties(file_number);
-- Geospatial queries
CREATE INDEX idx_properties_location ON properties USING GIST(location);
CREATE INDEX idx_properties_boundary ON properties USING GIST(boundary);
-- Monitoring queries
CREATE INDEX idx_properties_monitored ON properties(is_monitored) WHERE is_monitored = TRUE;
CREATE INDEX idx_properties_trust_score ON properties(current_trust_score);

-- ══════════════════════════════════════════════════════════════════
-- 4. DOCUMENTS
-- Every uploaded land document file
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE documents (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id             UUID REFERENCES properties(id) ON DELETE CASCADE,
    uploaded_by             UUID NOT NULL REFERENCES users(id),

    -- File info
    filename                VARCHAR(255) NOT NULL,
    file_size_bytes         INTEGER NOT NULL,
    mime_type               VARCHAR(50) NOT NULL,
    storage_key             TEXT NOT NULL,                -- S3/GCS object key
    storage_bucket          VARCHAR(100),

    -- Document metadata (extracted by OCR)
    document_type           document_type,
    declared_type           document_type,               -- What user said it was
    extracted_text          TEXT,                         -- Full OCR output
    extraction_confidence   DECIMAL(4, 3),               -- 0.000–1.000

    -- Parsed fields
    parsed_file_number      VARCHAR(50),
    parsed_owner_name       VARCHAR(255),
    parsed_issue_date       DATE,
    parsed_stamp_duty_ref   VARCHAR(50),
    parsed_governor_name    VARCHAR(100),
    parsed_survey_plan_no   VARCHAR(50),
    parsed_land_size        VARCHAR(50),
    parsed_coordinates      VARCHAR(100),

    -- Analysis results
    format_authenticity_score DECIMAL(4, 3),

    -- Flags
    is_potentially_forged   BOOLEAN NOT NULL DEFAULT FALSE,
    is_duplicate            BOOLEAN NOT NULL DEFAULT FALSE,
    duplicate_document_id   UUID REFERENCES documents(id),

    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documents_property ON documents(property_id);
CREATE INDEX idx_documents_uploaded_by ON documents(uploaded_by);
CREATE INDEX idx_documents_file_number ON documents(parsed_file_number);
CREATE INDEX idx_documents_type ON documents(document_type);
CREATE INDEX idx_documents_forged ON documents(is_potentially_forged) WHERE is_potentially_forged = TRUE;
-- Full text search on extracted document text
CREATE INDEX idx_documents_text_fts ON documents USING gin(to_tsvector('english', coalesce(extracted_text, '')));

-- ══════════════════════════════════════════════════════════════════
-- 5. VERIFICATIONS
-- Each time a user runs a full verification — the session record
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE verifications (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id),
    property_id         UUID REFERENCES properties(id),
    document_id         UUID REFERENCES documents(id),
    organization_id     UUID REFERENCES organizations(id),

    -- Status
    status              verification_status NOT NULL DEFAULT 'pending',
    started_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at        TIMESTAMPTZ,
    processing_ms       INTEGER,                          -- Time taken in ms

    -- Input
    declared_address    TEXT NOT NULL,
    declared_owner      VARCHAR(255) NOT NULL,
    declared_state      nigerian_state NOT NULL,
    declared_doc_type   document_type NOT NULL,
    declared_file_number VARCHAR(50),
    user_role           user_role NOT NULL,
    additional_notes    TEXT,

    -- Core Results
    trust_score         DECIMAL(5, 2),
    trust_level         trust_level,
    checks_passed       SMALLINT,
    checks_failed       SMALLINT,
    checks_warned       SMALLINT,

    -- Score breakdown (denormalized for quick access)
    score_document_authenticity DECIMAL(5, 2),
    score_registry_match        DECIMAL(5, 2),
    score_ownership_chain       DECIMAL(5, 2),
    score_encumbrance           DECIMAL(5, 2),
    score_geospatial            DECIMAL(5, 2),
    fraud_penalty               DECIMAL(5, 2),

    -- AI output
    ai_summary          TEXT,
    ai_recommendation   TEXT,
    fraud_risk_summary  TEXT,
    fraud_risk_level    VARCHAR(20),

    -- Ownership chain summary
    ownership_total_owners      SMALLINT,
    ownership_chain_integrity   DECIMAL(4, 3),
    ownership_has_gaps          BOOLEAN,
    ownership_has_disputes      BOOLEAN,

    -- Mode
    is_demo             BOOLEAN NOT NULL DEFAULT FALSE,
    api_version         VARCHAR(10) DEFAULT 'v1',
    ai_model_used       VARCHAR(50),

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_verifications_user ON verifications(user_id);
CREATE INDEX idx_verifications_property ON verifications(property_id);
CREATE INDEX idx_verifications_status ON verifications(status);
CREATE INDEX idx_verifications_trust_level ON verifications(trust_level);
CREATE INDEX idx_verifications_created ON verifications(created_at DESC);
CREATE INDEX idx_verifications_org ON verifications(organization_id);

-- ══════════════════════════════════════════════════════════════════
-- 6. VERIFICATION_CHECKS
-- Individual check results for each verification
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE verification_checks (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    verification_id     UUID NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,

    check_id            VARCHAR(50) NOT NULL,             -- e.g. 'format_validity'
    label               VARCHAR(100) NOT NULL,            -- Human-readable name
    status              check_status NOT NULL,
    detail              TEXT NOT NULL,                    -- Specific finding
    weight              DECIMAL(4, 3) NOT NULL,           -- Contribution to Trust Score
    evidence            TEXT,                             -- Supporting data/URL

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_checks_verification ON verification_checks(verification_id);
CREATE INDEX idx_checks_status ON verification_checks(status);
CREATE INDEX idx_checks_check_id ON verification_checks(check_id);

-- ══════════════════════════════════════════════════════════════════
-- 7. TRUST_SCORES
-- Full historical Trust Score timeline per property
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE trust_scores (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    verification_id     UUID REFERENCES verifications(id),

    score               DECIMAL(5, 2) NOT NULL,
    trust_level         trust_level NOT NULL,

    -- Component scores at this point in time
    doc_authenticity    DECIMAL(5, 2),
    registry_match      DECIMAL(5, 2),
    ownership_chain     DECIMAL(5, 2),
    encumbrance         DECIMAL(5, 2),
    geospatial          DECIMAL(5, 2),
    fraud_penalty       DECIMAL(5, 2),

    -- What changed since last score
    score_delta         DECIMAL(5, 2),                   -- +/- from previous
    change_reason       TEXT,                            -- Why score changed

    recorded_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_trust_scores_property ON trust_scores(property_id);
CREATE INDEX idx_trust_scores_recorded ON trust_scores(recorded_at DESC);
-- Efficiently find latest score per property
CREATE INDEX idx_trust_scores_property_date ON trust_scores(property_id, recorded_at DESC);

-- ══════════════════════════════════════════════════════════════════
-- 8. FRAUD_FLAGS
-- Detected fraud indicators per verification
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE fraud_flags (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    verification_id     UUID NOT NULL REFERENCES verifications(id) ON DELETE CASCADE,
    property_id         UUID REFERENCES properties(id),

    flag_id             VARCHAR(50) NOT NULL,             -- e.g. 'duplicate_title'
    source              VARCHAR(20) NOT NULL,             -- 'rule_based' | 'ai'
    severity            fraud_severity NOT NULL,
    title               VARCHAR(255) NOT NULL,
    description         TEXT NOT NULL,
    recommendation      TEXT NOT NULL,
    confidence          DECIMAL(4, 3) NOT NULL,           -- 0.000–1.000

    -- Resolution
    is_resolved         BOOLEAN NOT NULL DEFAULT FALSE,
    resolved_at         TIMESTAMPTZ,
    resolved_by         UUID REFERENCES users(id),
    resolution_notes    TEXT,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_fraud_flags_verification ON fraud_flags(verification_id);
CREATE INDEX idx_fraud_flags_property ON fraud_flags(property_id);
CREATE INDEX idx_fraud_flags_severity ON fraud_flags(severity);
CREATE INDEX idx_fraud_flags_unresolved ON fraud_flags(is_resolved) WHERE is_resolved = FALSE;
CREATE INDEX idx_fraud_flags_flag_id ON fraud_flags(flag_id);

-- ══════════════════════════════════════════════════════════════════
-- 9. OWNERSHIP_RECORDS
-- The complete ownership chain for each property
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE ownership_records (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    verification_id     UUID REFERENCES verifications(id),

    sequence_order      SMALLINT NOT NULL,                -- 1 = first owner, 2 = second, etc.

    -- Transfer details
    year                VARCHAR(10) NOT NULL,             -- e.g. '1987' or '1987-1990'
    event_date          DATE,                             -- Exact date if known
    owner_name          VARCHAR(255) NOT NULL,
    transaction_type    VARCHAR(50) NOT NULL,             -- 'purchase' | 'inheritance' | 'gift' | 'court_order'
    consideration       VARCHAR(100),                     -- Price paid or 'N/A'
    instrument          TEXT,                             -- Specific legal instrument reference

    -- Registry status
    is_registered       BOOLEAN NOT NULL DEFAULT TRUE,
    registry_ref        VARCHAR(100),                     -- Registry reference number

    -- Flags
    is_flagged          BOOLEAN NOT NULL DEFAULT FALSE,
    flag_reason         TEXT,
    is_gap              BOOLEAN NOT NULL DEFAULT FALSE,   -- True if there's no record between previous and this

    -- AI confidence
    ai_confidence       DECIMAL(4, 3),

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ownership_property ON ownership_records(property_id);
CREATE INDEX idx_ownership_verification ON ownership_records(verification_id);
CREATE INDEX idx_ownership_flagged ON ownership_records(is_flagged) WHERE is_flagged = TRUE;
CREATE UNIQUE INDEX idx_ownership_property_sequence ON ownership_records(property_id, sequence_order);
-- Search by owner name across all properties
CREATE INDEX idx_ownership_owner_trgm ON ownership_records USING gin(owner_name gin_trgm_ops);

-- ══════════════════════════════════════════════════════════════════
-- 10. FRAUD_ALERTS
-- Real-time alert events for monitored properties
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE fraud_alerts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,

    alert_type          alert_type NOT NULL,
    severity            fraud_severity NOT NULL,
    title               VARCHAR(255) NOT NULL,
    description         TEXT NOT NULL,
    recommended_action  TEXT NOT NULL,

    -- Source of the alert
    triggered_by        VARCHAR(50),                      -- 'system' | 'user_report' | 'registry_sync'
    source_verification_id UUID REFERENCES verifications(id),

    -- Notification tracking
    is_notified         BOOLEAN NOT NULL DEFAULT FALSE,
    notified_at         TIMESTAMPTZ,
    notification_channels TEXT[],                         -- ['email', 'sms', 'push']

    -- Resolution
    is_resolved         BOOLEAN NOT NULL DEFAULT FALSE,
    resolved_at         TIMESTAMPTZ,
    resolved_by         UUID REFERENCES users(id),
    resolution_notes    TEXT,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_alerts_property ON fraud_alerts(property_id);
CREATE INDEX idx_alerts_type ON fraud_alerts(alert_type);
CREATE INDEX idx_alerts_severity ON fraud_alerts(severity);
CREATE INDEX idx_alerts_unresolved ON fraud_alerts(is_resolved, created_at DESC) WHERE is_resolved = FALSE;

-- ══════════════════════════════════════════════════════════════════
-- 11. ALERT_SUBSCRIPTIONS
-- Which users are monitoring which properties
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE alert_subscriptions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    property_id         UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,

    -- Notification preferences
    notify_email        BOOLEAN NOT NULL DEFAULT TRUE,
    notify_sms          BOOLEAN NOT NULL DEFAULT FALSE,
    notify_push         BOOLEAN NOT NULL DEFAULT TRUE,

    -- What to be alerted about
    alert_on_any        BOOLEAN NOT NULL DEFAULT TRUE,
    alert_severity_min  fraud_severity DEFAULT 'low',    -- Minimum severity to alert on

    subscribed_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    cancelled_at        TIMESTAMPTZ,

    UNIQUE(user_id, property_id)
);

CREATE INDEX idx_subscriptions_user ON alert_subscriptions(user_id);
CREATE INDEX idx_subscriptions_property ON alert_subscriptions(property_id);
CREATE INDEX idx_subscriptions_active ON alert_subscriptions(property_id) WHERE cancelled_at IS NULL;

-- ══════════════════════════════════════════════════════════════════
-- 12. REGISTRY_CACHE
-- Cached results from Nigerian state land registry API calls
-- (avoids repeated costly/slow external API calls)
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE registry_cache (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    file_number         VARCHAR(50) NOT NULL,
    state               nigerian_state NOT NULL,

    -- Result
    found               BOOLEAN NOT NULL,
    registry_data       JSONB,                           -- Full response from registry API
    match_score         DECIMAL(4, 3),                  -- How confident the match is

    -- Cache management
    fetched_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at          TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '7 days',
    fetch_source        VARCHAR(50),                    -- e.g. 'lagos_gis_api'

    UNIQUE(file_number, state)
);

CREATE INDEX idx_registry_cache_file_state ON registry_cache(file_number, state);
CREATE INDEX idx_registry_cache_expires ON registry_cache(expires_at);

-- ══════════════════════════════════════════════════════════════════
-- 13. AUDIT_LOG
-- Immutable audit trail — every significant action recorded
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE audit_log (
    id                  BIGSERIAL PRIMARY KEY,           -- BIGSERIAL for high-volume logging
    user_id             UUID REFERENCES users(id),
    organization_id     UUID REFERENCES organizations(id),

    action              VARCHAR(100) NOT NULL,            -- e.g. 'verification.created', 'document.uploaded'
    resource_type       VARCHAR(50),                      -- e.g. 'verification', 'property'
    resource_id         UUID,
    ip_address          INET,
    user_agent          TEXT,

    -- Before/after state for mutations
    old_values          JSONB,
    new_values          JSONB,

    metadata            JSONB,                           -- Any additional context
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Partial indexes for common queries
CREATE INDEX idx_audit_user ON audit_log(user_id, created_at DESC);
CREATE INDEX idx_audit_action ON audit_log(action, created_at DESC);
CREATE INDEX idx_audit_resource ON audit_log(resource_type, resource_id);
CREATE INDEX idx_audit_created ON audit_log(created_at DESC);

-- ══════════════════════════════════════════════════════════════════
-- 14. API_KEYS
-- For B2B customers integrating LandVerify into their systems
-- ══════════════════════════════════════════════════════════════════

CREATE TABLE api_keys (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id     UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    created_by          UUID NOT NULL REFERENCES users(id),

    name                VARCHAR(100) NOT NULL,           -- e.g. "Production Key", "Staging Key"
    key_hash            TEXT NOT NULL UNIQUE,            -- bcrypt hash of the actual key
    key_prefix          VARCHAR(8) NOT NULL,             -- First 8 chars for display (e.g. 'lv_prod_')

    -- Permissions
    can_verify          BOOLEAN NOT NULL DEFAULT TRUE,
    can_read_alerts     BOOLEAN NOT NULL DEFAULT TRUE,
    can_register_property BOOLEAN NOT NULL DEFAULT FALSE,
    can_admin           BOOLEAN NOT NULL DEFAULT FALSE,

    -- Rate limiting
    rate_limit_per_min  INTEGER NOT NULL DEFAULT 30,
    rate_limit_per_day  INTEGER NOT NULL DEFAULT 1000,

    -- Usage
    total_calls         BIGINT NOT NULL DEFAULT 0,
    last_used_at        TIMESTAMPTZ,
    last_used_ip        INET,

    -- Lifecycle
    expires_at          TIMESTAMPTZ,
    revoked_at          TIMESTAMPTZ,
    revoked_by          UUID REFERENCES users(id),
    revoke_reason       TEXT,

    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_api_keys_org ON api_keys(organization_id);
CREATE INDEX idx_api_keys_prefix ON api_keys(key_prefix);
CREATE INDEX idx_api_keys_active ON api_keys(organization_id) WHERE revoked_at IS NULL;

-- ══════════════════════════════════════════════════════════════════
-- FUNCTIONS & TRIGGERS
-- ══════════════════════════════════════════════════════════════════

-- Auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_organizations_updated_at
    BEFORE UPDATE ON organizations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_properties_updated_at
    BEFORE UPDATE ON properties FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Sync property trust score when a new trust_score record is inserted
CREATE OR REPLACE FUNCTION sync_property_trust_score()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE properties
    SET
        current_trust_score = NEW.score,
        current_trust_level = NEW.trust_level,
        last_verified_at = NEW.recorded_at
    WHERE id = NEW.property_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_trust_score_to_property
    AFTER INSERT ON trust_scores FOR EACH ROW EXECUTE FUNCTION sync_property_trust_score();

-- Set has_active_alert on property when a new unresolved alert is inserted
CREATE OR REPLACE FUNCTION sync_property_alert_status()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' AND NOT NEW.is_resolved THEN
        UPDATE properties SET has_active_alert = TRUE WHERE id = NEW.property_id;
    ELSIF TG_OP = 'UPDATE' AND NEW.is_resolved AND OLD.is_resolved = FALSE THEN
        -- Check if any other unresolved alerts exist
        IF NOT EXISTS (
            SELECT 1 FROM fraud_alerts
            WHERE property_id = NEW.property_id AND is_resolved = FALSE AND id != NEW.id
        ) THEN
            UPDATE properties SET has_active_alert = FALSE WHERE id = NEW.property_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_alert_status_to_property
    AFTER INSERT OR UPDATE ON fraud_alerts FOR EACH ROW EXECUTE FUNCTION sync_property_alert_status();

-- Increment user verification count after each completed verification
CREATE OR REPLACE FUNCTION increment_user_verification_count()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'complete' AND (OLD.status IS NULL OR OLD.status != 'complete') THEN
        UPDATE users SET verifications_used = verifications_used + 1 WHERE id = NEW.user_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER increment_verification_count
    AFTER INSERT OR UPDATE ON verifications FOR EACH ROW EXECUTE FUNCTION increment_user_verification_count();

-- ══════════════════════════════════════════════════════════════════
-- VIEWS
-- ══════════════════════════════════════════════════════════════════

-- Active properties with latest trust score and alert status
CREATE VIEW v_property_summary AS
SELECT
    p.id,
    p.address,
    p.state,
    p.file_number,
    p.current_trust_score,
    p.current_trust_level,
    p.has_active_alert,
    p.is_disputed,
    p.last_verified_at,
    COUNT(DISTINCT a.id) FILTER (WHERE a.is_resolved = FALSE) AS active_alert_count,
    COUNT(DISTINCT v.id) AS total_verifications,
    MAX(v.created_at) AS last_verification_at
FROM properties p
LEFT JOIN fraud_alerts a ON a.property_id = p.id AND a.is_resolved = FALSE
LEFT JOIN verifications v ON v.property_id = p.id
WHERE p.deleted_at IS NULL
GROUP BY p.id;

-- User dashboard summary
CREATE VIEW v_user_dashboard AS
SELECT
    u.id AS user_id,
    u.full_name,
    u.plan,
    u.verifications_used,
    u.verifications_limit,
    COUNT(DISTINCT s.property_id) AS monitored_properties,
    COUNT(DISTINCT a.id) FILTER (WHERE a.is_resolved = FALSE) AS active_alerts,
    COUNT(DISTINCT v.id) AS total_verifications,
    AVG(v.trust_score) AS avg_trust_score_verified
FROM users u
LEFT JOIN alert_subscriptions s ON s.user_id = u.id AND s.cancelled_at IS NULL
LEFT JOIN fraud_alerts a ON a.property_id = s.property_id AND a.is_resolved = FALSE
LEFT JOIN verifications v ON v.user_id = u.id AND v.status = 'complete'
GROUP BY u.id;

-- Fraud flag leaderboard — most common fraud patterns
CREATE VIEW v_fraud_pattern_stats AS
SELECT
    flag_id,
    severity,
    source,
    COUNT(*) AS occurrence_count,
    AVG(confidence) AS avg_confidence,
    MAX(created_at) AS last_seen_at,
    COUNT(*) FILTER (WHERE is_resolved = FALSE) AS unresolved_count
FROM fraud_flags
GROUP BY flag_id, severity, source
ORDER BY occurrence_count DESC;

-- ══════════════════════════════════════════════════════════════════
-- SEED DATA — Nigerian States Reference
-- ══════════════════════════════════════════════════════════════════

-- File number format reference per state
CREATE TABLE state_registry_config (
    state               nigerian_state PRIMARY KEY,
    display_name        VARCHAR(100) NOT NULL,
    file_number_prefixes TEXT[] NOT NULL,
    registry_api_url    VARCHAR(255),
    registry_api_active BOOLEAN NOT NULL DEFAULT FALSE,
    capital             VARCHAR(100),
    population_est      INTEGER
);

INSERT INTO state_registry_config (state, display_name, file_number_prefixes, capital, population_est) VALUES
('lagos',      'Lagos State',      ARRAY['LG','LA','LAG'],        'Ikeja',    15000000),
('abuja_fct',  'Abuja (FCT)',       ARRAY['AB','ABJ','FCT'],       'Abuja',     3600000),
('rivers',     'Rivers State',     ARRAY['RV','RIV','PH'],         'Port Harcourt', 7000000),
('ogun',       'Ogun State',       ARRAY['OG','OGN'],             'Abeokuta',  4500000),
('kano',       'Kano State',       ARRAY['KN','KAN'],             'Kano',     13000000),
('enugu',      'Enugu State',      ARRAY['EN','ENU'],             'Enugu',     4000000),
('delta',      'Delta State',      ARRAY['DL','DEL'],             'Asaba',     5000000),
('oyo',        'Oyo State',        ARRAY['OY','OYO'],             'Ibadan',    8000000),
('kaduna',     'Kaduna State',     ARRAY['KD','KAD'],             'Kaduna',    8200000),
('anambra',    'Anambra State',    ARRAY['AN','ANM'],             'Awka',      5200000);

-- ══════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- Users can only see their own verifications and properties they monitor
-- ══════════════════════════════════════════════════════════════════

ALTER TABLE verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users see only their own verifications
CREATE POLICY verifications_user_policy ON verifications
    USING (user_id = current_setting('app.current_user_id')::UUID);

-- Organization members see org verifications
CREATE POLICY verifications_org_policy ON verifications
    USING (organization_id IN (
        SELECT organization_id FROM users
        WHERE id = current_setting('app.current_user_id')::UUID
    ));

-- Users see only their uploaded documents
CREATE POLICY documents_user_policy ON documents
    USING (uploaded_by = current_setting('app.current_user_id')::UUID);

-- ══════════════════════════════════════════════════════════════════
-- SCHEMA COMPLETE
-- ══════════════════════════════════════════════════════════════════
-- Total tables: 14
-- Total indexes: 40+
-- Total triggers: 4
-- Total views: 3
-- RLS policies: 3
-- ══════════════════════════════════════════════════════════════════
