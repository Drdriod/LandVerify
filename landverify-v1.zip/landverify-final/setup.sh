#!/bin/bash
# LandVerify — One-command setup
# Run: bash setup.sh

set -e
echo ""
echo "╔════════════════════════════════════════════╗"
echo "║     LandVerify — Local Setup               ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# 1. Python version check
python_version=$(python3 --version 2>&1 | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "✅ Python $python_version detected"

# 2. Virtual environment
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
echo "✅ Virtual environment active"

# 3. Install dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt -q
echo "✅ Dependencies installed"

# 4. Tesseract OCR (optional — for real document scanning)
if command -v tesseract &> /dev/null; then
    echo "✅ Tesseract OCR detected (real documents will be scanned)"
else
    echo "⚠️  Tesseract not found — using mock OCR (fine for testing)"
    echo "   Install with: brew install tesseract  (Mac)"
    echo "                 sudo apt install tesseract-ocr  (Linux)"
fi

# 5. PostgreSQL (optional)
echo ""
echo "╔════════════════════════════════════════════╗"
echo "║  DATABASE SETUP (Optional)                 ║"
echo "║  Skip this if you just want to test the API ║"
echo "╚════════════════════════════════════════════╝"

if command -v psql &> /dev/null; then
    echo "PostgreSQL detected. Setting up database..."
    psql postgres -c "CREATE USER landverify WITH PASSWORD 'landverify';" 2>/dev/null || echo "  User already exists"
    psql postgres -c "CREATE DATABASE landverify OWNER landverify;" 2>/dev/null || echo "  Database already exists"
    echo "✅ Database ready"
else
    echo "⚠️  PostgreSQL not running — API works without it (demo mode)"
    echo "   Install: brew install postgresql  (Mac)"
    echo "            sudo apt install postgresql  (Linux)"
fi

# 6. .env check
if grep -q "your-api-key-here" .env; then
    echo ""
    echo "⚠️  Add your Anthropic API key to .env:"
    echo "   ANTHROPIC_API_KEY=sk-ant-..."
    echo "   Get it free at: https://console.anthropic.com"
fi

echo ""
echo "╔════════════════════════════════════════════╗"
echo "║  READY! Start the backend:                 ║"
echo "║                                            ║"
echo "║  source venv/bin/activate                  ║"
echo "║  uvicorn app.main:app --reload             ║"
echo "║                                            ║"
echo "║  Then open landverify.html in your browser ║"
echo "╚════════════════════════════════════════════╝"
echo ""
